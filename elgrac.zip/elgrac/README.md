# elgrac

Un réseau social complet : comptes, publications avec photos, j'aime, commentaires, amis, messagerie privée et notifications. Sans aucune dépendance : seulement Node.js.

## Lancer

1. Installe [Node.js](https://nodejs.org) **version 22.13 ou plus récente**.
2. Dans ce dossier :
   ```
   npm start
   ```
3. Ouvre http://localhost:3000 et crée un compte.

Pour essayer avec des comptes de démonstration : `npm run seed` (amina, patrick, sarah ; mot de passe `demo12345`). Ne pas utiliser en ligne.

**Sur ton téléphone** : branche-le sur le même Wi-Fi que l'ordinateur et ouvre l'adresse « Réseau » affichée au démarrage.

## Installer comme application Android

Ouvre le site dans Chrome, puis menu ⋮ → « Installer l'application » (il faut une adresse HTTPS une fois en ligne). Elle apparaît ensuite sur l'écran d'accueil, en plein écran.

## Tests

```
npm test
```

## Où sont les données ?

Dans le dossier `data/` (base `elgrac.db` + photos dans `uploads/`). **Sauvegarde ce dossier régulièrement.**

## Réglages (variables d'environnement)

| Variable | Rôle | Défaut |
|---|---|---|
| `PORT` | port du serveur | 3000 |
| `HOST` | adresse d'écoute | 0.0.0.0 |
| `DATA_DIR` | dossier des données | ./data |
| `NODE_ENV=production` | active le cookie sécurisé (HTTPS) | — |
| `COOKIE_SECURE=1` | force le cookie sécurisé | — |
| `TRUST_PROXY=1` | fait confiance à l'IP transmise par un proxy | — |

## Mettre en ligne

Loue un petit serveur (VPS), installe Node 22.13+, lance `NODE_ENV=production TRUST_PROXY=1 npm start` (avec pm2 ou systemd) derrière un proxy HTTPS (Caddy ou nginx). Un hébergeur avec disque persistant (Railway, Fly.io, Render…) convient aussi : monte `DATA_DIR` sur ce disque.

## Limites actuelles (honnêtes)

- Actualisation par interrogation régulière (pas de WebSocket) : quelques secondes de délai.
- SQLite sur un seul serveur : très bien pour des milliers d'utilisateurs, à revoir au-delà.
- Pas de confirmation d'e-mail ni de mot de passe oublié.
- Pas de signalement ni de modération : indispensable avant d'ouvrir au public.
- Google Play : possible plus tard en emballant le site (TWA).
