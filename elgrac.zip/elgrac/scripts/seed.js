'use strict';
// Crée quelques comptes et publications de démonstration pour essayer elgrac.
// Usage : npm run seed   (mot de passe de tous les comptes : demo12345)
const { db, tx } = require('../src/db');
const { hashPassword } = require('../src/auth');

const DEMO = [
  ['amina', 'Amina Tshimanga', 'Étudiante à Kinshasa. J’aime la musique et les bonnes histoires.'],
  ['patrick', 'Patrick Ilunga', 'Développeur et passionné de football.'],
  ['sarah', 'Sarah Mbuyi', 'Cuisine congolaise et voyages.'],
];
const POSTS = [
  ['amina', 'Bienvenue sur elgrac ! Ici, on se retrouve, on partage et on discute. 🇨🇩'],
  ['patrick', 'Qui regarde le match ce soir ? Je cherche des amis pour en parler.'],
  ['sarah', 'Aujourd’hui : poulet à la moambe. Je partage la recette si vous voulez !'],
  ['amina', 'Citation du jour : « Le chemin se fait en marchant. »'],
];

(async () => {
  const row = db.prepare('SELECT COUNT(*) n FROM users WHERE email LIKE ?').get('%@demo.elgrac');
  if (row.n > 0) { console.log('Les comptes de démonstration existent déjà.'); return; }
  const hash = await hashPassword('demo12345');
  const now = Date.now();
  tx(() => {
    const ids = {};
    for (const [u, name, bio] of DEMO) {
      ids[u] = Number(db.prepare('INSERT INTO users(username, display_name, email, password_hash, bio, created_at) VALUES (?,?,?,?,?,?)')
        .run(u, name, `${u}@demo.elgrac`, hash, bio, now).lastInsertRowid);
    }
    POSTS.forEach(([u, body], i) =>
      db.prepare('INSERT INTO posts(user_id, body, created_at) VALUES (?,?,?)').run(ids[u], body, now - (POSTS.length - i) * 3600e3));
    db.prepare("INSERT INTO friendships(requester_id, addressee_id, status, created_at) VALUES (?,?,'accepted',?)").run(ids.amina, ids.patrick, now);
  });
  console.log('Comptes de démonstration créés : amina, patrick, sarah (mot de passe : demo12345).');
})();
