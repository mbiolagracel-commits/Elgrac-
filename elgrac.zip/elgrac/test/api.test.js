'use strict';
// Lancer avec : npm test
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');
const http = require('node:http');
const test = require('node:test');
const assert = require('node:assert/strict');

// Base de données et dossier d'images temporaires : le test ne touche pas à tes vraies données.
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'elgrac-test-'));
process.env.DATA_DIR = tmp;
process.env.DB_FILE = ':memory:';
process.env.LOG_REQUESTS = '0';
process.env.AUTH_RATE_MAX = '1000';

const { createServer } = require('../server');

const PNG = Buffer.from(
  'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');

let base;
let server;

test.before(async () => {
  server = createServer();
  await new Promise((r) => server.listen(0, '127.0.0.1', r));
  base = `http://127.0.0.1:${server.address().port}`;
});
test.after(() => {
  server.close();
  fs.rmSync(tmp, { recursive: true, force: true });
});

/** Un « navigateur » avec son propre cookie de session. */
function client() {
  let cookie = '';
  async function call(method, url, body, headers = {}) {
    const opts = { method, headers: { ...headers } };
    if (cookie) opts.headers.cookie = cookie;
    if (body !== undefined) {
      if (Buffer.isBuffer(body)) {
        opts.body = body;
      } else {
        opts.body = JSON.stringify(body);
        opts.headers['content-type'] = 'application/json';
      }
    }
    const res = await fetch(base + url, opts);
    const set = res.headers.getSetCookie ? res.headers.getSetCookie() : [];
    if (set.length) {
      const first = set[0].split(';')[0];
      cookie = first.endsWith('=') ? '' : first;
    }
    const ct = res.headers.get('content-type') || '';
    const data = ct.includes('json') ? await res.json() : await res.arrayBuffer();
    return { status: res.status, data, headers: res.headers };
  }
  return {
    get: (u) => call('GET', u),
    post: (u, b) => call('POST', u, b === undefined ? undefined : b),
    patch: (u, b) => call('PATCH', u, b),
    del: (u) => call('DELETE', u),
    raw: (u, buf, type) => call('POST', u, buf, { 'content-type': type }),
  };
}

const alice = client();
const bob = client();
const carol = client();
let aliceId, bobId, carolId;

async function signup(c, username, name) {
  const r = await c.post('/api/auth/register', {
    username, display_name: name, email: `${username}@exemple.cd`, password: 'motdepasse123',
  });
  assert.equal(r.status, 200, JSON.stringify(r.data));
  return r.data.user.id;
}

test('santé et accès protégé', async () => {
  const c = client();
  assert.equal((await c.get('/api/health')).status, 200);
  assert.equal((await c.get('/api/me')).status, 401);
  assert.equal((await c.get('/api/posts')).status, 401);
});

test('inscription : validations, doublons, connexion', async () => {
  const c = client();
  const base = { username: 'zoe_1', display_name: 'Zoé', email: 'zoe@exemple.cd', password: 'motdepasse123' };
  assert.equal((await c.post('/api/auth/register', { ...base, password: 'court' })).status, 400);
  assert.equal((await c.post('/api/auth/register', { ...base, username: 'a b' })).status, 400);
  assert.equal((await c.post('/api/auth/register', { ...base, username: 'admin' })).status, 400);
  assert.equal((await c.post('/api/auth/register', { ...base, email: 'pas-un-email' })).status, 400);

  aliceId = await signup(alice, 'alice', 'Alice Kabeya');
  bobId = await signup(bob, 'bob', 'Bob Mukendi');
  carolId = await signup(carol, 'carol', 'Carol Tshala');

  assert.equal((await client().post('/api/auth/register', { ...base, username: 'ALICE' })).status, 409);
  assert.equal((await client().post('/api/auth/register', { ...base, username: 'autre', email: 'ALICE@exemple.cd' })).status, 409);

  const me = await alice.get('/api/me');
  assert.equal(me.data.user.username, 'alice');
  assert.equal(me.data.user.password_hash, undefined);

  const login = client();
  assert.equal((await login.post('/api/auth/login', { identifier: 'alice', password: 'mauvais' })).status, 401);
  assert.equal((await login.post('/api/auth/login', { identifier: 'alice', password: 'motdepasse123' })).status, 200);
  assert.equal((await login.get('/api/me')).status, 200);
  await login.post('/api/auth/logout');
  assert.equal((await login.get('/api/me')).status, 401);
  // connexion par e-mail
  assert.equal((await login.post('/api/auth/login', { identifier: 'alice@exemple.cd', password: 'motdepasse123' })).status, 200);
});

test('limite d\'essais de connexion par compte', async () => {
  const c = client();
  let last;
  for (let i = 0; i < 10; i++) last = await c.post('/api/auth/login', { identifier: 'victime', password: 'x' + i });
  assert.equal(last.status, 429);
});

test('publications, fil Découvrir et fil Amis', async () => {
  const p = await alice.post('/api/posts', { body: 'Bonjour elgrac !' });
  assert.equal(p.status, 200);
  assert.equal(p.data.post.author.username, 'alice');
  assert.equal((await alice.post('/api/posts', { body: '   ' })).status, 400);
  assert.equal((await alice.post('/api/posts', { body: 'x'.repeat(2001) })).status, 400);

  const all = await bob.get('/api/posts');
  assert.equal(all.data.posts.length, 1);
  const friends = await bob.get('/api/posts?scope=friends');
  assert.equal(friends.data.posts.length, 0, 'pas encore amis');
});

test('demandes d\'amis', async () => {
  assert.equal((await alice.post(`/api/friends/request/${aliceId}`)).status, 400);
  assert.equal((await alice.post(`/api/friends/request/${bobId}`)).data.relation, 'sent');
  assert.equal((await alice.post(`/api/friends/request/${bobId}`)).status, 409);

  const counters = await bob.get('/api/counters');
  assert.equal(counters.data.requests, 1);
  assert.equal(counters.data.notifications, 1);
  const reqs = await bob.get('/api/friends/requests');
  assert.equal(reqs.data.incoming[0].username, 'alice');

  // alice ne peut pas accepter sa propre demande
  assert.equal((await alice.post(`/api/friends/accept/${bobId}`)).status, 404);
  assert.equal((await bob.post(`/api/friends/accept/${aliceId}`)).data.relation, 'friends');

  const profile = await bob.get('/api/users/alice');
  assert.equal(profile.data.relation, 'friends');
  assert.equal(profile.data.stats.friends, 1);
  assert.equal((await bob.get('/api/posts?scope=friends')).data.posts.length, 1);
  assert.equal((await carol.get('/api/posts?scope=friends')).data.posts.length, 0);

  // refuser puis redemander
  await carol.post(`/api/friends/request/${aliceId}`);
  assert.equal((await alice.del(`/api/friends/${carolId}`)).data.relation, 'none');
  assert.equal((await alice.get('/api/counters')).data.requests, 0);
});

test('j\'aime, commentaires et notifications', async () => {
  const postId = (await alice.get('/api/posts')).data.posts[0].id;
  const like = await bob.post(`/api/posts/${postId}/like`);
  assert.deepEqual([like.data.liked, like.data.likes], [true, 1]);
  const unlike = await bob.post(`/api/posts/${postId}/like`);
  assert.deepEqual([unlike.data.liked, unlike.data.likes], [false, 0]);
  await bob.post(`/api/posts/${postId}/like`);
  await alice.post(`/api/posts/${postId}/like`); // son propre j'aime : pas de notification

  const c = await bob.post(`/api/posts/${postId}/comments`, { body: 'Bravo' });
  assert.equal(c.status, 200);
  assert.equal((await bob.post(`/api/posts/${postId}/comments`, { body: '' })).status, 400);
  assert.equal((await alice.get(`/api/posts/${postId}/comments`)).data.comments.length, 1);

  const notes = (await alice.get('/api/notifications')).data.notifications;
  const types = notes.map((n) => n.type);
  assert.ok(types.includes('like'));
  assert.ok(types.includes('comment'));
  assert.ok(types.includes('friend_accept'));
  assert.equal(notes.filter((n) => n.type === 'like').length, 1, 'un seul j\'aime notifié');
  assert.ok((await alice.get('/api/counters')).data.notifications >= 3);
  await alice.post('/api/notifications/read');
  assert.equal((await alice.get('/api/counters')).data.notifications, 0);

  // Carol ne peut pas supprimer le commentaire de Bob ni la publication d'Alice.
  assert.equal((await carol.del(`/api/comments/${c.data.comment.id}`)).status, 403);
  assert.equal((await carol.del(`/api/posts/${postId}`)).status, 403);
  // L'auteure de la publication peut supprimer le commentaire.
  assert.equal((await alice.del(`/api/comments/${c.data.comment.id}`)).status, 200);
});

test('messages privés entre amis seulement', async () => {
  assert.equal((await carol.post('/api/messages/alice', { body: 'salut' })).status, 403);
  assert.equal((await alice.post('/api/messages/bob', { body: 'Salut Bob' })).status, 200);
  assert.equal((await alice.post('/api/messages/bob', { body: '' })).status, 400);
  assert.equal((await alice.post('/api/messages/alice', { body: 'moi' })).status, 400);

  assert.equal((await bob.get('/api/counters')).data.messages, 1);
  const convs = await bob.get('/api/messages');
  assert.equal(convs.data.conversations[0].unread, 1);
  const thread = await bob.get('/api/messages/alice');
  assert.equal(thread.data.messages.length, 1);
  assert.equal(thread.data.can_send, true);
  assert.equal((await bob.get('/api/counters')).data.messages, 0);

  await bob.post('/api/messages/alice', { body: 'Salut Alice' });
  const after = await alice.get(`/api/messages/bob?after=${thread.data.messages[0].id}`);
  assert.equal(after.data.messages.length, 1);
  assert.equal(after.data.messages[0].body, 'Salut Alice');
  // Carol ne voit rien de cette conversation.
  assert.equal((await carol.get('/api/messages')).data.conversations.length, 0);
});

test('envoi d\'images : contrôle du contenu et propriété', async () => {
  const fake = await alice.raw('/api/upload', Buffer.from('<script>alert(1)</script>'), 'image/png');
  assert.equal(fake.status, 400);
  const big = await alice.raw('/api/upload', Buffer.concat([PNG, Buffer.alloc(6 * 1024 * 1024)]), 'image/png');
  assert.equal(big.status, 413);

  const up = await alice.raw('/api/upload', PNG, 'image/png');
  assert.equal(up.status, 200, JSON.stringify(up.data));
  assert.match(up.data.file, /^[a-f0-9]{32}\.png$/);

  const img = await fetch(`${base}/uploads/${up.data.file}`);
  assert.equal(img.status, 200);
  assert.equal(img.headers.get('content-type'), 'image/png');
  assert.equal(img.headers.get('x-content-type-options'), 'nosniff');

  // Bob ne peut pas publier avec l'image d'Alice.
  assert.equal((await bob.post('/api/posts', { body: 'volé', image: up.data.file })).status, 400);
  const withImage = await alice.post('/api/posts', { body: '', image: up.data.file });
  assert.equal(withImage.status, 200);
  assert.equal(withImage.data.post.image, up.data.file);
  assert.equal((await alice.patch('/api/me', { avatar: up.data.file })).data.user.avatar, up.data.file);
  assert.equal((await bob.patch('/api/me', { avatar: up.data.file })).status, 400);
  assert.equal((await client().raw('/api/upload', PNG, 'image/png')).status, 401);
});

test('sécurité : origine, format, chemins, injection', async () => {
  // Requête venant d'un autre site
  const status = await new Promise((resolve) => {
    const u = new URL(base + '/api/auth/logout');
    const req = http.request({ host: u.hostname, port: u.port, path: u.pathname, method: 'POST',
      headers: { origin: 'http://evil.example', 'content-length': 0 } }, (res) => { res.resume(); resolve(res.statusCode); });
    req.end();
  });
  assert.equal(status, 403);

  // Corps qui n'est pas du JSON
  const r = await alice.post('/api/posts', undefined);
  assert.equal(r.status, 400);
  assert.equal((await alice.raw('/api/posts', Buffer.from('x'), 'text/plain')).status, 415);

  // Sorties de dossier
  for (const p of ['/..%2f..%2fetc%2fpasswd', '/%2e%2e/server.js', '/uploads/../../etc/passwd', '/src/db.js', '/uploads/nimportequoi.png']) {
    const res = await fetch(base + p);
    assert.ok([400, 404].includes(res.status), `${p} -> ${res.status}`);
  }
  // En-têtes de protection
  const home = await fetch(base + '/');
  assert.match(home.headers.get('content-security-policy') || '', /script-src 'self'/);

  // Injection SQL et caractères spéciaux de recherche
  const inj = await alice.get('/api/users/search?q=' + encodeURIComponent("' OR 1=1 --"));
  assert.equal(inj.status, 200);
  assert.equal(inj.data.users.length, 0);
  const wild = await alice.get('/api/users/search?q=' + encodeURIComponent('%%'));
  assert.equal(wild.data.users.length, 0);
  const found = await alice.get('/api/users/search?q=bo');
  assert.equal(found.data.users[0].username, 'bob');
  assert.equal(found.data.users[0].email, undefined);

  // Le texte reste du texte : le serveur ne le transforme pas en HTML
  const xss = await alice.post('/api/posts', { body: '<img src=x onerror=alert(1)>' });
  assert.equal(xss.data.post.body, '<img src=x onerror=alert(1)>');
});

test('profil : modification et mot de passe', async () => {
  const upd = await alice.patch('/api/me', { display_name: 'Alice K.', bio: 'Étudiante à Kinshasa' });
  assert.equal(upd.data.user.display_name, 'Alice K.');
  assert.equal((await alice.patch('/api/me', { bio: 'x'.repeat(161) })).status, 400);
  assert.equal((await alice.patch('/api/me', { display_name: 'A' })).status, 400);

  assert.equal((await alice.post('/api/me/password', { current: 'faux', next: 'nouveaumotdepasse' })).status, 403);
  assert.equal((await alice.post('/api/me/password', { current: 'motdepasse123', next: 'nouveaumotdepasse' })).status, 200);
  const again = client();
  assert.equal((await again.post('/api/auth/login', { identifier: 'alice', password: 'motdepasse123' })).status, 401);
  assert.equal((await again.post('/api/auth/login', { identifier: 'alice', password: 'nouveaumotdepasse' })).status, 200);
});

test('suppression de publication et retrait d\'ami', async () => {
  const mine = (await alice.get('/api/users/alice/posts')).data.posts;
  assert.ok(mine.length >= 2);
  assert.equal((await alice.del(`/api/posts/${mine[0].id}`)).status, 200);
  assert.equal((await alice.get(`/api/posts/${mine[0].id}`)).status, 404);

  assert.equal((await alice.del(`/api/friends/${bobId}`)).data.relation, 'none');
  assert.equal((await bob.get('/api/users/alice')).data.relation, 'none');
  // Plus amis : la conversation reste lisible, mais on ne peut plus écrire.
  assert.equal((await bob.post('/api/messages/alice', { body: 'encore ?' })).status, 403);
  assert.equal((await bob.get('/api/messages/alice')).data.can_send, false);
});
