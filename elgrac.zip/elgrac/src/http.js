'use strict';
const fs = require('node:fs');
const path = require('node:path');
const { PUBLIC, UPLOADS } = require('./paths');

const TRUST_PROXY = process.env.TRUST_PROXY === '1';
const SECURE = process.env.COOKIE_SECURE === '1' || process.env.NODE_ENV === 'production';
const AUTH_RATE_MAX = Number(process.env.AUTH_RATE_MAX) || 60;

class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}
const bad = (message) => new HttpError(400, message);
const str = (v) => (typeof v === 'string' ? v.trim() : '');

/* ---------- routeur minimal ---------- */
class Router {
  constructor() {
    this.routes = [];
  }
  add(method, pattern, opts, handler) {
    if (typeof opts === 'function') {
      handler = opts;
      opts = {};
    }
    const keys = [];
    const re = new RegExp(
      '^' + pattern.replace(/:([A-Za-z_]+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '/?$'
    );
    this.routes.push({ method, re, keys, opts, handler });
  }
  get(p, o, h) { this.add('GET', p, o, h); }
  post(p, o, h) { this.add('POST', p, o, h); }
  patch(p, o, h) { this.add('PATCH', p, o, h); }
  del(p, o, h) { this.add('DELETE', p, o, h); }
  match(method, pathname) {
    for (const r of this.routes) {
      if (r.method !== method) continue;
      const m = r.re.exec(pathname);
      if (!m) continue;
      const params = {};
      r.keys.forEach((k, i) => { params[k] = decodeURIComponent(m[i + 1]); });
      return { route: r, params };
    }
    return null;
  }
}

/* ---------- limitation du nombre de requêtes ---------- */
const buckets = new Map();
function hit(key, max, windowMs, message) {
  const now = Date.now();
  let b = buckets.get(key);
  if (!b || b.reset <= now) {
    b = { count: 0, reset: now + windowMs };
    buckets.set(key, b);
  }
  b.count += 1;
  if (b.count > max) {
    const wait = Math.ceil((b.reset - now) / 1000);
    throw new HttpError(429, message || `Trop de requêtes. Réessaie dans ${wait} s.`);
  }
}
setInterval(() => {
  const now = Date.now();
  for (const [k, b] of buckets) if (b.reset <= now) buckets.delete(k);
}, 60_000).unref();

/* ---------- utilitaires requête / réponse ---------- */
function clientIp(req) {
  if (TRUST_PROXY) {
    const xff = req.headers['x-forwarded-for'];
    if (xff) return String(xff).split(',')[0].trim();
  }
  return req.socket.remoteAddress || 'inconnu';
}

function parseCookies(header) {
  const out = {};
  if (!header) return out;
  for (const part of String(header).split(';')) {
    const i = part.indexOf('=');
    if (i < 0) continue;
    try {
      out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
    } catch { /* cookie illisible : ignoré */ }
  }
  return out;
}

function readBody(req, max, tooBigMessage = 'Fichier trop volumineux.') {
  return new Promise((resolve, reject) => {
    const declared = Number(req.headers['content-length']);
    if (declared > max) {
      req.resume();
      return reject(new HttpError(413, tooBigMessage));
    }
    const chunks = [];
    let size = 0;
    let failed = false;
    req.on('data', (c) => {
      if (failed) return;
      size += c.length;
      if (size > max) {
        failed = true;
        chunks.length = 0;
        reject(new HttpError(413, tooBigMessage));
        return;
      }
      chunks.push(c);
    });
    req.on('end', () => { if (!failed) resolve(Buffer.concat(chunks)); });
    req.on('error', reject);
  });
}

async function readJson(req) {
  const len = Number(req.headers['content-length'] || 0);
  if (!len && !req.headers['transfer-encoding']) return {};
  if (!String(req.headers['content-type'] || '').includes('application/json')) {
    throw new HttpError(415, 'Format de requête non pris en charge.');
  }
  const buf = await readBody(req, 64 * 1024, 'Requête trop volumineuse.');
  if (!buf.length) return {};
  let data;
  try {
    data = JSON.parse(buf.toString('utf8'));
  } catch {
    throw bad('Requête invalide.');
  }
  if (!data || typeof data !== 'object' || Array.isArray(data)) throw bad('Requête invalide.');
  return data;
}

function sendJson(res, status, data) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store',
  });
  res.end(body);
}

function sendError(res, e) {
  const status = e instanceof HttpError ? e.status : 500;
  if (!(e instanceof HttpError)) console.error(e);
  if (res.headersSent) return res.end();
  if (res.req && res.req.headers && status === 413) res.setHeader('Connection', 'close');
  sendJson(res, status, { error: e instanceof HttpError ? e.message : 'Erreur interne du serveur.' });
}

/** Refuse les requêtes qui modifient des données et viennent d'un autre site. */
function checkOrigin(req) {
  const origin = req.headers.origin;
  if (!origin) return;
  let host;
  try { host = new URL(origin).host; } catch { throw new HttpError(403, 'Origine refusée.'); }
  const expected = (TRUST_PROXY && req.headers['x-forwarded-host']) || req.headers.host;
  if (host !== expected) throw new HttpError(403, 'Origine refusée.');
}

function setSecurityHeaders(res) {
  res.setHeader('Content-Security-Policy',
    "default-src 'self'; script-src 'self'; style-src 'self' https://fonts.googleapis.com; " +
    "font-src https://fonts.gstatic.com; img-src 'self' data: blob:; connect-src 'self'; " +
    "manifest-src 'self'; worker-src 'self'; object-src 'none'; base-uri 'self'; " +
    "form-action 'self'; frame-ancestors 'none'");
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'same-origin');
  res.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  if (SECURE) res.setHeader('Strict-Transport-Security', 'max-age=15552000');
}

/* ---------- fichiers statiques ---------- */
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.webp': 'image/webp',
  '.gif': 'image/gif',
  '.ico': 'image/x-icon',
  '.txt': 'text/plain; charset=utf-8',
};

function sendFile(req, res, file, cache) {
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) return sendError(res, new HttpError(404, 'Page introuvable.'));
    const type = MIME[path.extname(file).toLowerCase()] || 'application/octet-stream';
    res.writeHead(200, {
      'Content-Type': type,
      'Content-Length': st.size,
      'Last-Modified': st.mtime.toUTCString(),
      'Cache-Control': cache,
    });
    if (req.method === 'HEAD') return res.end();
    const stream = fs.createReadStream(file);
    stream.on('error', () => res.destroy());
    stream.pipe(res);
  });
}

async function serveStatic(req, res, url) {
  if (req.method !== 'GET' && req.method !== 'HEAD') throw new HttpError(405, 'Méthode non autorisée.');
  let p;
  try { p = decodeURIComponent(url.pathname); } catch { throw bad('Adresse invalide.'); }
  if (p.includes('\0')) throw bad('Adresse invalide.');

  if (p.startsWith('/uploads/')) {
    const name = p.slice('/uploads/'.length);
    if (!/^[a-f0-9]{32}\.(jpg|png|webp|gif)$/.test(name)) throw new HttpError(404, 'Page introuvable.');
    return sendFile(req, res, path.join(UPLOADS, name), 'public, max-age=31536000, immutable');
  }
  if (p === '/') p = '/index.html';
  const file = path.join(PUBLIC, path.normalize(p));
  if (!file.startsWith(PUBLIC + path.sep)) throw new HttpError(404, 'Page introuvable.');
  const cache = p === '/sw.js' || p === '/index.html' ? 'no-cache' : 'public, max-age=300';
  return sendFile(req, res, file, cache);
}

module.exports = {
  HttpError, bad, str, Router, hit, clientIp, parseCookies, readBody, readJson,
  sendJson, sendError, checkOrigin, setSecurityHeaders, serveStatic,
  SECURE, AUTH_RATE_MAX,
};
