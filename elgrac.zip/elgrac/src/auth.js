'use strict';
const crypto = require('node:crypto');
const { promisify } = require('node:util');
const { db } = require('./db');
const { parseCookies, SECURE } = require('./http');

const scrypt = promisify(crypto.scrypt);
const COOKIE = 'elgrac_sid';
const TTL = 30 * 24 * 60 * 60 * 1000;
const sha = (s) => crypto.createHash('sha256').update(s).digest('hex');

async function hashPassword(password) {
  const salt = crypto.randomBytes(16);
  const key = await scrypt(password, salt, 64, { N: 16384, r: 8, p: 1 });
  return `scrypt$16384$${salt.toString('hex')}$${key.toString('hex')}`;
}

async function verifyPassword(password, stored) {
  const [alg, n, saltHex, keyHex] = String(stored).split('$');
  if (alg !== 'scrypt') return false;
  const expected = Buffer.from(keyHex, 'hex');
  const key = await scrypt(password, Buffer.from(saltHex, 'hex'), expected.length, { N: Number(n), r: 8, p: 1 });
  return key.length === expected.length && crypto.timingSafeEqual(key, expected);
}

// Utilisé quand le compte n'existe pas, pour que la réponse prenne le même temps.
const DUMMY_HASH = (() => {
  const salt = Buffer.alloc(16, 1);
  const key = crypto.scryptSync('dummy-password', salt, 64, { N: 16384, r: 8, p: 1 });
  return `scrypt$16384$${salt.toString('hex')}$${key.toString('hex')}`;
})();

function newSession(userId) {
  const token = crypto.randomBytes(32).toString('base64url');
  db.prepare('INSERT INTO sessions(token_hash, user_id, expires_at) VALUES (?, ?, ?)')
    .run(sha(token), userId, Date.now() + TTL);
  return token;
}

function tokenOf(req) {
  const token = parseCookies(req.headers.cookie)[COOKIE];
  return token && token.length < 100 ? token : null;
}

function loadUser(req) {
  const token = tokenOf(req);
  if (!token) return null;
  return db.prepare(
    'SELECT u.* FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ? AND s.expires_at > ?'
  ).get(sha(token), Date.now()) || null;
}

function currentTokenHash(req) {
  const token = tokenOf(req);
  return token ? sha(token) : null;
}

function destroySession(req) {
  const hash = currentTokenHash(req);
  if (hash) db.prepare('DELETE FROM sessions WHERE token_hash = ?').run(hash);
}

function cookieString(value, maxAgeSeconds) {
  return `${COOKIE}=${value}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${maxAgeSeconds}${SECURE ? '; Secure' : ''}`;
}
function setSessionCookie(ctx, token) {
  ctx.res.setHeader('Set-Cookie', cookieString(token, TTL / 1000));
}
function clearSessionCookie(ctx) {
  ctx.res.setHeader('Set-Cookie', cookieString('', 0));
}

function purgeExpiredSessions() {
  db.prepare('DELETE FROM sessions WHERE expires_at <= ?').run(Date.now());
}

module.exports = {
  hashPassword, verifyPassword, DUMMY_HASH, newSession, loadUser, currentTokenHash,
  destroySession, setSessionCookie, clearSessionCookie, purgeExpiredSessions,
};
