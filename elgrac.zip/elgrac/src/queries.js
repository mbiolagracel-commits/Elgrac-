'use strict';
const { db } = require('./db');

/** Ce que les autres membres ont le droit de voir d'un compte. */
function pub(u) {
  return { id: u.id, username: u.username, display_name: u.display_name, avatar: u.avatar || null, bio: u.bio || '' };
}

/** Ce que le propriétaire voit de son propre compte. */
function selfUser(u) {
  return { ...pub(u), email: u.email, created_at: u.created_at };
}

const POST_SELECT = `
SELECT p.id, p.body, p.image, p.created_at,
       u.id AS author_id, u.username, u.display_name, u.avatar,
       (SELECT COUNT(*) FROM likes l WHERE l.post_id = p.id) AS likes,
       EXISTS (SELECT 1 FROM likes l WHERE l.post_id = p.id AND l.user_id = ?) AS liked,
       (SELECT COUNT(*) FROM comments c WHERE c.post_id = p.id) AS comments
FROM posts p JOIN users u ON u.id = p.user_id`;

function shapePost(r) {
  return {
    id: r.id,
    body: r.body,
    image: r.image,
    created_at: r.created_at,
    likes: r.likes,
    liked: !!r.liked,
    comments: r.comments,
    author: { id: r.author_id, username: r.username, display_name: r.display_name, avatar: r.avatar || null },
  };
}

function listPosts(meId, where = '1 = 1', params = [], limit = 15) {
  const rows = db.prepare(`${POST_SELECT} WHERE ${where} ORDER BY p.id DESC LIMIT ?`).all(meId, ...params, limit);
  return rows.map(shapePost);
}

function getPost(meId, id) {
  const row = db.prepare(`${POST_SELECT} WHERE p.id = ?`).get(meId, id);
  return row ? shapePost(row) : null;
}

/** 'self' | 'friends' | 'sent' (j'ai envoyé une demande) | 'received' | 'none' */
function relation(meId, otherId) {
  if (meId === otherId) return 'self';
  const f = db.prepare(
    `SELECT requester_id, status FROM friendships
     WHERE (requester_id = ? AND addressee_id = ?) OR (requester_id = ? AND addressee_id = ?)`
  ).get(meId, otherId, otherId, meId);
  if (!f) return 'none';
  if (f.status === 'accepted') return 'friends';
  return f.requester_id === meId ? 'sent' : 'received';
}

function areFriends(a, b) {
  return relation(a, b) === 'friends';
}

/** Crée une notification (jamais pour soi-même, jamais en double pour un j'aime). */
function notify(userId, actorId, type, postId = null) {
  if (userId === actorId) return;
  if (type === 'like') {
    const exists = db.prepare(
      'SELECT 1 FROM notifications WHERE user_id = ? AND actor_id = ? AND type = ? AND post_id = ?'
    ).get(userId, actorId, type, postId);
    if (exists) return;
  }
  db.prepare('INSERT INTO notifications(user_id, actor_id, type, post_id, created_at) VALUES (?, ?, ?, ?, ?)')
    .run(userId, actorId, type, postId, Date.now());
}

const FRIEND_FILTER = `(p.user_id = ? OR p.user_id IN (
  SELECT CASE WHEN requester_id = ? THEN addressee_id ELSE requester_id END
  FROM friendships WHERE status = 'accepted' AND (requester_id = ? OR addressee_id = ?)))`;

module.exports = { pub, selfUser, listPosts, getPost, relation, areFriends, notify, FRIEND_FILTER };
