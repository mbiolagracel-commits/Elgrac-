'use strict';
const crypto = require('node:crypto');
const fs = require('node:fs');
const path = require('node:path');
const { db } = require('../db');
const { bad, readBody } = require('../http');
const { UPLOADS } = require('../paths');

const MAX_BYTES = 5 * 1024 * 1024;

/** Reconnaît le vrai type d'une image à son contenu, pas à son nom ni à ce que le navigateur déclare. */
function detectImage(buf) {
  if (buf.length < 12) return null;
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'jpg';
  if (buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'png';
  const head = buf.toString('latin1', 0, 6);
  if (head === 'GIF87a' || head === 'GIF89a') return 'gif';
  if (buf.toString('latin1', 0, 4) === 'RIFF' && buf.toString('latin1', 8, 12) === 'WEBP') return 'webp';
  return null;
}

module.exports = function register(router) {
  // Le navigateur envoie l'image telle quelle dans le corps de la requête.
  router.post('/api/upload', { auth: true, raw: true, rate: ['upload', 40, 60 * 60 * 1000, 'user'] }, async (ctx) => {
    const buf = await readBody(ctx.req, MAX_BYTES, 'Image trop lourde (5 Mo maximum).');
    const ext = detectImage(buf);
    if (!ext) throw bad('Format non pris en charge. Utilise une image JPG, PNG, WebP ou GIF.');
    const name = `${crypto.randomBytes(16).toString('hex')}.${ext}`;
    await fs.promises.writeFile(path.join(UPLOADS, name), buf, { flag: 'wx' });
    db.prepare('INSERT INTO uploads(filename, user_id, created_at) VALUES (?, ?, ?)').run(name, ctx.user.id, Date.now());
    return { file: name };
  });
};
