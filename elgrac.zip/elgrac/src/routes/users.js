'use strict';
const { db } = require('../db');
const { HttpError, str } = require('../http');
const { pub, listPosts, relation } = require('../queries');

const PAGE = 15;

function findUser(username) {
  const u = db.prepare('SELECT * FROM users WHERE username = ?').get(username);
  if (!u) throw new HttpError(404, 'Ce profil est introuvable.');
  return u;
}

module.exports = function register(router) {
  // Les routes précises doivent venir avant /api/users/:username.
  router.get('/api/users/search', { auth: true, rate: ['search', 120, 60 * 1000, 'user'] }, (ctx) => {
    const q = str(ctx.query.q).slice(0, 40);
    if (q.length < 2) return { users: [] };
    const like = `%${q.replace(/[\\%_]/g, '\\$&')}%`;
    const rows = db.prepare(
      `SELECT id, username, display_name, avatar, bio FROM users
       WHERE id <> ? AND (username LIKE ? ESCAPE '\\' OR display_name LIKE ? ESCAPE '\\')
       ORDER BY display_name LIMIT 20`
    ).all(ctx.user.id, like, like);
    return { users: rows.map((r) => ({ ...pub(r), relation: relation(ctx.user.id, r.id) })) };
  });

  router.get('/api/users/suggestions', { auth: true }, (ctx) => {
    const me = ctx.user.id;
    const rows = db.prepare(
      `SELECT u.id, u.username, u.display_name, u.avatar, u.bio FROM users u
       WHERE u.id <> ? AND NOT EXISTS (
         SELECT 1 FROM friendships f
         WHERE (f.requester_id = ? AND f.addressee_id = u.id) OR (f.requester_id = u.id AND f.addressee_id = ?))
       ORDER BY u.id DESC LIMIT 6`
    ).all(me, me, me);
    return { users: rows.map(pub) };
  });

  router.get('/api/users/:username', { auth: true }, (ctx) => {
    const u = findUser(ctx.params.username);
    const posts = db.prepare('SELECT COUNT(*) AS n FROM posts WHERE user_id = ?').get(u.id).n;
    const friends = db.prepare(
      `SELECT COUNT(*) AS n FROM friendships WHERE status = 'accepted' AND (requester_id = ? OR addressee_id = ?)`
    ).get(u.id, u.id).n;
    return { user: { ...pub(u), created_at: u.created_at }, stats: { posts, friends }, relation: relation(ctx.user.id, u.id) };
  });

  router.get('/api/users/:username/posts', { auth: true }, (ctx) => {
    const u = findUser(ctx.params.username);
    const before = Number(ctx.query.before) || 0;
    const where = before ? 'p.user_id = ? AND p.id < ?' : 'p.user_id = ?';
    const params = before ? [u.id, before] : [u.id];
    const posts = listPosts(ctx.user.id, where, params, PAGE);
    return { posts, next: posts.length === PAGE ? posts[posts.length - 1].id : null };
  });

  router.get('/api/users/:username/friends', { auth: true }, (ctx) => {
    const u = findUser(ctx.params.username);
    const rows = db.prepare(
      `SELECT x.id, x.username, x.display_name, x.avatar, x.bio FROM friendships f
       JOIN users x ON x.id = CASE WHEN f.requester_id = ? THEN f.addressee_id ELSE f.requester_id END
       WHERE f.status = 'accepted' AND (f.requester_id = ? OR f.addressee_id = ?)
       ORDER BY x.display_name LIMIT 60`
    ).all(u.id, u.id, u.id);
    return { users: rows.map(pub) };
  });
};
