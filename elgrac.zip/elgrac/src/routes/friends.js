'use strict';
const { db, tx } = require('../db');
const { HttpError, bad } = require('../http');
const { pub, relation, notify } = require('../queries');

function targetUser(idParam, meId) {
  const id = Number(idParam);
  if (!Number.isInteger(id) || id <= 0) throw bad('Membre invalide.');
  if (id === meId) throw bad('Tu ne peux pas faire cette action avec toi-même.');
  const u = db.prepare('SELECT id, username, display_name, avatar, bio FROM users WHERE id = ?').get(id);
  if (!u) throw new HttpError(404, 'Membre introuvable.');
  return u;
}

module.exports = function register(router) {
  router.get('/api/friends', { auth: true }, (ctx) => {
    const me = ctx.user.id;
    const rows = db.prepare(
      `SELECT x.id, x.username, x.display_name, x.avatar, x.bio FROM friendships f
       JOIN users x ON x.id = CASE WHEN f.requester_id = ? THEN f.addressee_id ELSE f.requester_id END
       WHERE f.status = 'accepted' AND (f.requester_id = ? OR f.addressee_id = ?)
       ORDER BY x.display_name`
    ).all(me, me, me);
    return { users: rows.map(pub) };
  });

  router.get('/api/friends/requests', { auth: true }, (ctx) => {
    const me = ctx.user.id;
    const incoming = db.prepare(
      `SELECT x.id, x.username, x.display_name, x.avatar, x.bio, f.created_at FROM friendships f
       JOIN users x ON x.id = f.requester_id
       WHERE f.addressee_id = ? AND f.status = 'pending' ORDER BY f.id DESC`
    ).all(me);
    const sent = db.prepare(
      `SELECT x.id, x.username, x.display_name, x.avatar, x.bio, f.created_at FROM friendships f
       JOIN users x ON x.id = f.addressee_id
       WHERE f.requester_id = ? AND f.status = 'pending' ORDER BY f.id DESC`
    ).all(me);
    const shape = (r) => ({ ...pub(r), created_at: r.created_at });
    return { incoming: incoming.map(shape), sent: sent.map(shape) };
  });

  router.post('/api/friends/request/:userId', { auth: true, rate: ['friend', 100, 60 * 60 * 1000, 'user'] }, (ctx) => {
    const me = ctx.user.id;
    const other = targetUser(ctx.params.userId, me);
    return tx(() => {
      const rel = relation(me, other.id);
      if (rel === 'friends') throw new HttpError(409, 'Vous êtes déjà amis.');
      if (rel === 'sent') throw new HttpError(409, 'Ta demande est déjà envoyée.');
      if (rel === 'received') {
        // L'autre personne t'a déjà écrit : on accepte directement.
        db.prepare(`UPDATE friendships SET status = 'accepted' WHERE requester_id = ? AND addressee_id = ?`).run(other.id, me);
        notify(other.id, me, 'friend_accept');
        return { relation: 'friends' };
      }
      db.prepare(`INSERT INTO friendships(requester_id, addressee_id, status, created_at) VALUES (?, ?, 'pending', ?)`)
        .run(me, other.id, Date.now());
      notify(other.id, me, 'friend_request');
      return { relation: 'sent' };
    });
  });

  router.post('/api/friends/accept/:userId', { auth: true }, (ctx) => {
    const me = ctx.user.id;
    const other = targetUser(ctx.params.userId, me);
    const res = db.prepare(
      `UPDATE friendships SET status = 'accepted' WHERE requester_id = ? AND addressee_id = ? AND status = 'pending'`
    ).run(other.id, me);
    if (!res.changes) throw new HttpError(404, 'Aucune demande à accepter.');
    notify(other.id, me, 'friend_accept');
    return { relation: 'friends' };
  });

  // Retirer un ami, refuser une demande reçue ou annuler une demande envoyée.
  router.del('/api/friends/:userId', { auth: true }, (ctx) => {
    const me = ctx.user.id;
    const other = targetUser(ctx.params.userId, me);
    tx(() => {
      db.prepare(
        `DELETE FROM friendships WHERE (requester_id = ? AND addressee_id = ?) OR (requester_id = ? AND addressee_id = ?)`
      ).run(me, other.id, other.id, me);
      db.prepare(
        `DELETE FROM notifications WHERE type = 'friend_request' AND
         ((user_id = ? AND actor_id = ?) OR (user_id = ? AND actor_id = ?))`
      ).run(me, other.id, other.id, me);
    });
    return { relation: 'none' };
  });
};
