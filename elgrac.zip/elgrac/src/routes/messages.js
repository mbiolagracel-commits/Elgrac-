'use strict';
const { db } = require('../db');
const { HttpError, bad, str } = require('../http');
const { pub, areFriends } = require('../queries');

function otherUser(username) {
  const u = db.prepare('SELECT id, username, display_name, avatar, bio FROM users WHERE username = ?').get(username);
  if (!u) throw new HttpError(404, 'Ce membre est introuvable.');
  return u;
}

const shape = (m) => ({ id: m.id, sender_id: m.sender_id, body: m.body, created_at: m.created_at });

module.exports = function register(router) {
  router.get('/api/messages', { auth: true }, (ctx) => {
    const me = ctx.user.id;
    const rows = db.prepare(
      `SELECT u.id, u.username, u.display_name, u.avatar, u.bio,
              m.body AS last_body, m.sender_id AS last_sender, m.created_at AS last_at,
              (SELECT COUNT(*) FROM messages x WHERE x.sender_id = u.id AND x.receiver_id = ? AND x.read_at IS NULL) AS unread
       FROM users u
       JOIN messages m ON m.id = (
         SELECT MAX(id) FROM messages
         WHERE (sender_id = ? AND receiver_id = u.id) OR (sender_id = u.id AND receiver_id = ?))
       WHERE u.id <> ? ORDER BY m.id DESC LIMIT 50`
    ).all(me, me, me, me);
    return {
      conversations: rows.map((r) => ({
        user: pub(r), last_body: r.last_body, last_mine: r.last_sender === me, last_at: r.last_at, unread: r.unread,
      })),
    };
  });

  router.get('/api/messages/:username', { auth: true }, (ctx) => {
    const me = ctx.user.id;
    const other = otherUser(ctx.params.username);
    const after = Number(ctx.query.after) || 0;
    const rows = db.prepare(
      `SELECT id, sender_id, body, created_at FROM messages
       WHERE ((sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)) AND id > ?
       ORDER BY id DESC LIMIT 100`
    ).all(me, other.id, other.id, me, after).reverse();
    db.prepare('UPDATE messages SET read_at = ? WHERE sender_id = ? AND receiver_id = ? AND read_at IS NULL')
      .run(Date.now(), other.id, me);
    return { user: pub(other), can_send: areFriends(me, other.id), messages: rows.map(shape) };
  });

  router.post('/api/messages/:username', { auth: true, rate: ['message', 300, 60 * 60 * 1000, 'user'] }, (ctx) => {
    const me = ctx.user.id;
    const other = otherUser(ctx.params.username);
    if (other.id === me) throw bad('Tu ne peux pas t\'écrire à toi-même.');
    if (!areFriends(me, other.id)) throw new HttpError(403, 'Vous devez être amis pour vous écrire.');
    const body = str(ctx.body.body);
    if (!body) throw bad('Écris un message.');
    if (body.length > 1000) throw bad('Ton message est trop long (1000 caractères maximum).');
    const id = Number(db.prepare('INSERT INTO messages(sender_id, receiver_id, body, created_at) VALUES (?, ?, ?, ?)')
      .run(me, other.id, body, Date.now()).lastInsertRowid);
    return { message: shape(db.prepare('SELECT id, sender_id, body, created_at FROM messages WHERE id = ?').get(id)) };
  });
};
