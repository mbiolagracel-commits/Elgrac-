'use strict';
const { db } = require('../db');
const { HttpError, bad, str, hit, AUTH_RATE_MAX } = require('../http');
const auth = require('../auth');
const { selfUser } = require('../queries');

const USERNAME_RE = /^[A-Za-z0-9_.]{3,20}$/;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const RESERVED = new Set(['admin', 'administrator', 'root', 'api', 'support', 'elgrac', 'moderator', 'system', 'search', 'suggestions', 'me']);
const AUTH_RATE = ['auth', AUTH_RATE_MAX, 15 * 60 * 1000];
const LOGIN_ID_MAX = Number(process.env.LOGIN_ID_MAX) || 8;

module.exports = function register(router) {
  router.post('/api/auth/register', { rate: AUTH_RATE }, async (ctx) => {
    const username = str(ctx.body.username);
    const display = str(ctx.body.display_name).replace(/\s+/g, ' ');
    const email = str(ctx.body.email).toLowerCase();
    const password = typeof ctx.body.password === 'string' ? ctx.body.password : '';

    if (!USERNAME_RE.test(username)) throw bad("Le nom d'utilisateur doit avoir 3 à 20 caractères : lettres, chiffres, point ou tiret bas.");
    if (RESERVED.has(username.toLowerCase())) throw bad("Ce nom d'utilisateur n'est pas disponible.");
    if (display.length < 2 || display.length > 40) throw bad('Le nom affiché doit avoir entre 2 et 40 caractères.');
    if (!EMAIL_RE.test(email) || email.length > 120) throw bad('Adresse e-mail invalide.');
    if (password.length < 8 || password.length > 128) throw bad('Le mot de passe doit avoir au moins 8 caractères.');
    if (db.prepare('SELECT 1 FROM users WHERE username = ?').get(username)) throw new HttpError(409, "Ce nom d'utilisateur est déjà pris.");
    if (db.prepare('SELECT 1 FROM users WHERE email = ?').get(email)) throw new HttpError(409, 'Un compte existe déjà avec cet e-mail.');

    const hash = await auth.hashPassword(password);
    let id;
    try {
      id = Number(db.prepare(
        'INSERT INTO users(username, display_name, email, password_hash, created_at) VALUES (?, ?, ?, ?, ?)'
      ).run(username, display, email, hash, Date.now()).lastInsertRowid);
    } catch {
      throw new HttpError(409, 'Ce compte existe déjà.');
    }
    auth.setSessionCookie(ctx, auth.newSession(id));
    return { user: selfUser(db.prepare('SELECT * FROM users WHERE id = ?').get(id)) };
  });

  router.post('/api/auth/login', { rate: AUTH_RATE }, async (ctx) => {
    const identifier = str(ctx.body.identifier);
    const password = typeof ctx.body.password === 'string' ? ctx.body.password : '';
    if (!identifier || !password || identifier.length > 120 || password.length > 128) {
      throw bad('Entre ton identifiant et ton mot de passe.');
    }
    // Protège chaque compte contre les essais en série, même depuis des adresses IP différentes.
    hit(`login:${identifier.toLowerCase()}`, LOGIN_ID_MAX, 15 * 60 * 1000,
      'Trop d\'essais pour ce compte. Réessaie dans quelques minutes.');
    const user = db.prepare('SELECT * FROM users WHERE username = ? OR email = ?').get(identifier, identifier.toLowerCase());
    const ok = await auth.verifyPassword(password, user ? user.password_hash : auth.DUMMY_HASH);
    if (!user || !ok) throw new HttpError(401, 'Identifiants incorrects.');
    auth.setSessionCookie(ctx, auth.newSession(user.id));
    return { user: selfUser(user) };
  });

  router.post('/api/auth/logout', {}, (ctx) => {
    auth.destroySession(ctx.req);
    auth.clearSessionCookie(ctx);
    return { ok: true };
  });

  router.get('/api/me', { auth: true }, (ctx) => ({ user: selfUser(ctx.user) }));

  router.patch('/api/me', { auth: true }, (ctx) => {
    const me = ctx.user;
    const display = ctx.body.display_name === undefined ? me.display_name : str(ctx.body.display_name).replace(/\s+/g, ' ');
    const bio = ctx.body.bio === undefined ? me.bio : str(ctx.body.bio);
    let avatar = me.avatar;
    if (ctx.body.avatar !== undefined) {
      const file = ctx.body.avatar === null ? null : String(ctx.body.avatar);
      if (file && !db.prepare('SELECT 1 FROM uploads WHERE filename = ? AND user_id = ?').get(file, me.id)) {
        throw bad('Photo introuvable. Envoie-la de nouveau.');
      }
      avatar = file;
    }
    if (display.length < 2 || display.length > 40) throw bad('Le nom affiché doit avoir entre 2 et 40 caractères.');
    if (bio.length > 160) throw bad('La description est limitée à 160 caractères.');
    db.prepare('UPDATE users SET display_name = ?, bio = ?, avatar = ? WHERE id = ?').run(display, bio, avatar, me.id);
    return { user: selfUser(db.prepare('SELECT * FROM users WHERE id = ?').get(me.id)) };
  });

  router.post('/api/me/password', { auth: true, rate: ['password', 10, 15 * 60 * 1000, 'user'] }, async (ctx) => {
    const current = typeof ctx.body.current === 'string' ? ctx.body.current : '';
    const next = typeof ctx.body.next === 'string' ? ctx.body.next : '';
    if (next.length < 8 || next.length > 128) throw bad('Le nouveau mot de passe doit avoir au moins 8 caractères.');
    if (!(await auth.verifyPassword(current, ctx.user.password_hash))) throw new HttpError(403, 'Mot de passe actuel incorrect.');
    const hash = await auth.hashPassword(next);
    db.prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(hash, ctx.user.id);
    // Déconnecte tous les autres appareils.
    db.prepare('DELETE FROM sessions WHERE user_id = ? AND token_hash <> ?')
      .run(ctx.user.id, auth.currentTokenHash(ctx.req) || '');
    return { ok: true };
  });
};
