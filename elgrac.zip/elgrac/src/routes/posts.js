'use strict';
const { db } = require('../db');
const { HttpError, bad, str } = require('../http');
const { pub, listPosts, getPost, notify, FRIEND_FILTER } = require('../queries');

const PAGE = 15;

function postOr404(id) {
  const post = db.prepare('SELECT id, user_id FROM posts WHERE id = ?').get(Number(id));
  if (!post) throw new HttpError(404, 'Publication introuvable.');
  return post;
}

function shapeComment(r) {
  return {
    id: r.id, body: r.body, created_at: r.created_at, post_id: r.post_id,
    author: { id: r.user_id, username: r.username, display_name: r.display_name, avatar: r.avatar || null },
  };
}

const COMMENT_SELECT = `SELECT c.id, c.post_id, c.user_id, c.body, c.created_at, u.username, u.display_name, u.avatar
  FROM comments c JOIN users u ON u.id = c.user_id`;

module.exports = function register(router) {
  router.get('/api/posts', { auth: true }, (ctx) => {
    const me = ctx.user.id;
    const where = [];
    const params = [];
    if (ctx.query.scope === 'friends') {
      where.push(FRIEND_FILTER);
      params.push(me, me, me, me);
    }
    const before = Number(ctx.query.before) || 0;
    if (before) {
      where.push('p.id < ?');
      params.push(before);
    }
    const posts = listPosts(me, where.join(' AND ') || '1 = 1', params, PAGE);
    return { posts, next: posts.length === PAGE ? posts[posts.length - 1].id : null };
  });

  router.get('/api/posts/:id', { auth: true }, (ctx) => {
    const post = getPost(ctx.user.id, Number(ctx.params.id));
    if (!post) throw new HttpError(404, 'Publication introuvable.');
    return { post };
  });

  router.post('/api/posts', { auth: true, rate: ['post', 60, 60 * 60 * 1000, 'user'] }, (ctx) => {
    const me = ctx.user.id;
    const body = str(ctx.body.body);
    const image = ctx.body.image == null || ctx.body.image === '' ? null : String(ctx.body.image);
    if (body.length > 2000) throw bad('Ta publication est trop longue (2000 caractères maximum).');
    if (!body && !image) throw bad('Écris quelque chose ou ajoute une photo.');
    if (image && !db.prepare('SELECT 1 FROM uploads WHERE filename = ? AND user_id = ?').get(image, me)) {
      throw bad('Photo introuvable. Envoie-la de nouveau.');
    }
    const id = Number(db.prepare('INSERT INTO posts(user_id, body, image, created_at) VALUES (?, ?, ?, ?)')
      .run(me, body, image, Date.now()).lastInsertRowid);
    return { post: getPost(me, id) };
  });

  router.del('/api/posts/:id', { auth: true }, (ctx) => {
    const post = postOr404(ctx.params.id);
    if (post.user_id !== ctx.user.id) throw new HttpError(403, 'Tu ne peux supprimer que tes publications.');
    db.prepare('DELETE FROM posts WHERE id = ?').run(post.id);
    return { ok: true };
  });

  router.post('/api/posts/:id/like', { auth: true, rate: ['like', 240, 60 * 60 * 1000, 'user'] }, (ctx) => {
    const post = postOr404(ctx.params.id);
    const me = ctx.user.id;
    const had = db.prepare('SELECT 1 FROM likes WHERE post_id = ? AND user_id = ?').get(post.id, me);
    if (had) {
      db.prepare('DELETE FROM likes WHERE post_id = ? AND user_id = ?').run(post.id, me);
    } else {
      db.prepare('INSERT INTO likes(post_id, user_id, created_at) VALUES (?, ?, ?)').run(post.id, me, Date.now());
      notify(post.user_id, me, 'like', post.id);
    }
    const likes = db.prepare('SELECT COUNT(*) AS n FROM likes WHERE post_id = ?').get(post.id).n;
    return { liked: !had, likes };
  });

  router.get('/api/posts/:id/comments', { auth: true }, (ctx) => {
    const post = postOr404(ctx.params.id);
    const rows = db.prepare(`${COMMENT_SELECT} WHERE c.post_id = ? ORDER BY c.id ASC LIMIT 200`).all(post.id);
    return { comments: rows.map(shapeComment) };
  });

  router.post('/api/posts/:id/comments', { auth: true, rate: ['comment', 120, 60 * 60 * 1000, 'user'] }, (ctx) => {
    const post = postOr404(ctx.params.id);
    const body = str(ctx.body.body);
    if (!body) throw bad('Écris un commentaire.');
    if (body.length > 500) throw bad('Ton commentaire est trop long (500 caractères maximum).');
    const id = Number(db.prepare('INSERT INTO comments(post_id, user_id, body, created_at) VALUES (?, ?, ?, ?)')
      .run(post.id, ctx.user.id, body, Date.now()).lastInsertRowid);
    notify(post.user_id, ctx.user.id, 'comment', post.id);
    return { comment: shapeComment(db.prepare(`${COMMENT_SELECT} WHERE c.id = ?`).get(id)) };
  });

  router.del('/api/comments/:id', { auth: true }, (ctx) => {
    const c = db.prepare(
      'SELECT c.id, c.user_id, p.user_id AS post_owner FROM comments c JOIN posts p ON p.id = c.post_id WHERE c.id = ?'
    ).get(Number(ctx.params.id));
    if (!c) throw new HttpError(404, 'Commentaire introuvable.');
    if (c.user_id !== ctx.user.id && c.post_owner !== ctx.user.id) throw new HttpError(403, 'Action non autorisée.');
    db.prepare('DELETE FROM comments WHERE id = ?').run(c.id);
    return { ok: true };
  });
};

module.exports.pub = pub;
