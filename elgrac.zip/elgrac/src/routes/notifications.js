'use strict';
const { db } = require('../db');

module.exports = function register(router) {
  router.get('/api/notifications', { auth: true }, (ctx) => {
    const rows = db.prepare(
      `SELECT n.id, n.type, n.post_id, n.created_at, n.read_at,
              u.id AS actor_id, u.username, u.display_name, u.avatar
       FROM notifications n JOIN users u ON u.id = n.actor_id
       WHERE n.user_id = ? ORDER BY n.id DESC LIMIT 40`
    ).all(ctx.user.id);
    return {
      notifications: rows.map((r) => ({
        id: r.id, type: r.type, post_id: r.post_id, created_at: r.created_at, unread: !r.read_at,
        actor: { id: r.actor_id, username: r.username, display_name: r.display_name, avatar: r.avatar || null },
      })),
    };
  });

  router.post('/api/notifications/read', { auth: true }, (ctx) => {
    db.prepare('UPDATE notifications SET read_at = ? WHERE user_id = ? AND read_at IS NULL').run(Date.now(), ctx.user.id);
    return { ok: true };
  });

  // Les pastilles rouges de la barre de navigation.
  router.get('/api/counters', { auth: true }, (ctx) => {
    const me = ctx.user.id;
    const one = (sql) => db.prepare(sql).get(me).n;
    return {
      notifications: one('SELECT COUNT(*) AS n FROM notifications WHERE user_id = ? AND read_at IS NULL'),
      messages: one('SELECT COUNT(*) AS n FROM messages WHERE receiver_id = ? AND read_at IS NULL'),
      requests: one(`SELECT COUNT(*) AS n FROM friendships WHERE addressee_id = ? AND status = 'pending'`),
    };
  });
};
