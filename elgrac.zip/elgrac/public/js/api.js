// Communication avec le serveur.

export class ApiError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

async function request(method, path, body, opts = {}) {
  const init = { method, credentials: 'same-origin', headers: {} };
  if (body instanceof Blob) {
    init.body = body;
    init.headers['Content-Type'] = body.type || 'application/octet-stream';
  } else if (body !== undefined) {
    init.body = JSON.stringify(body);
    init.headers['Content-Type'] = 'application/json';
  }

  let res;
  try {
    res = await fetch(path, init);
  } catch {
    throw new ApiError(0, 'Pas de connexion à Internet. Vérifie ton réseau et réessaie.');
  }

  let data = null;
  if ((res.headers.get('content-type') || '').includes('json')) {
    try { data = await res.json(); } catch { /* réponse vide */ }
  }
  if (!res.ok) {
    if (res.status === 401 && !opts.noAuthRedirect) window.dispatchEvent(new CustomEvent('elgrac:unauth'));
    throw new ApiError(res.status, (data && data.error) || 'Une erreur est survenue. Réessaie.');
  }
  return data;
}

export const api = {
  get: (path, opts) => request('GET', path, undefined, opts),
  post: (path, body, opts) => request('POST', path, body, opts),
  patch: (path, body, opts) => request('PATCH', path, body, opts),
  del: (path, opts) => request('DELETE', path, undefined, opts),
};

/**
 * Réduit la photo avant l'envoi : une photo de téléphone de 4 Mo passe à environ 300 Ko.
 * Ça économise les données mobiles de tout le monde.
 */
export async function prepareImage(file, maxSide = 1600) {
  if (!file.type.startsWith('image/') || file.type === 'image/gif') return file;
  try {
    const bmp = await createImageBitmap(file);
    const scale = Math.min(1, maxSide / Math.max(bmp.width, bmp.height));
    if (scale === 1 && file.size < 350 * 1024) {
      if (bmp.close) bmp.close();
      return file;
    }
    const canvas = document.createElement('canvas');
    canvas.width = Math.round(bmp.width * scale);
    canvas.height = Math.round(bmp.height * scale);
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#fff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(bmp, 0, 0, canvas.width, canvas.height);
    if (bmp.close) bmp.close();
    const blob = await new Promise((resolve) => canvas.toBlob(resolve, 'image/jpeg', 0.82));
    return blob && blob.size < file.size ? blob : file;
  } catch {
    return file;
  }
}

/** Envoie une image et renvoie le nom du fichier enregistré sur le serveur. */
export async function uploadImage(file, maxSide = 1600) {
  const blob = await prepareImage(file, maxSide);
  const res = await request('POST', '/api/upload', blob);
  return res.file;
}
