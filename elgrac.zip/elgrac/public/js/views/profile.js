// Page d'un membre : présentation, publications et amis.
import { api } from '../api.js';
import { h, avatar, plural, memberSince, errorState, emptyState, skeletonCards } from '../ui.js';
import { feed, relationActions } from '../components.js';

export default async function profile({ root, params }) {
  const username = params[0];
  root.append(skeletonCards(2));

  let data;
  try {
    data = await api.get(`/api/users/${encodeURIComponent(username)}`);
  } catch (e) {
    root.textContent = '';
    root.append(errorState(e.status === 404 ? "Ce profil n'existe pas." : e.message));
    return;
  }
  const { user, stats } = data;
  const self = data.relation === 'self';
  document.title = `${user.display_name} · elgrac`;

  const meta = h('p', { class: 'muted small' });
  function paintMeta() {
    meta.textContent = `Membre depuis ${memberSince(user.created_at)} · ${plural(stats.posts, 'publication', 'publications')} · ${plural(stats.friends, 'ami', 'amis')}`;
  }
  paintMeta();

  const actions = self
    ? h('a', { class: 'btn', href: '#/settings', text: 'Modifier le profil' })
    : relationActions(user, data.relation, {
        onChange: async () => {
          try {
            const fresh = await api.get(`/api/users/${encodeURIComponent(username)}`);
            stats.friends = fresh.stats.friends;
            paintMeta();
          } catch { /* sans importance */ }
        },
      });

  const header = h('section', { class: 'card profile' },
    h('div', { class: 'cover', 'aria-hidden': 'true' }),
    h('div', { class: 'profile-body' },
      avatar(user, 'xl'),
      h('div', { class: 'profile-id' },
        h('h1', { text: user.display_name }),
        h('p', { class: 'muted', text: `@${user.username}` }),
        user.bio ? h('p', { class: 'bio', text: user.bio }) : null,
        meta),
      h('div', { class: 'profile-actions' }, actions)));

  const posts = feed(
    (before) => api.get(`/api/users/${encodeURIComponent(username)}/posts${before ? `?before=${before}` : ''}`),
    () => emptyState(self ? "Tu n'as encore rien publié" : 'Rien à voir pour le moment',
      self ? 'Ta première publication apparaîtra ici.' : `${user.display_name} n'a pas encore publié.`),
  );

  const friendsBox = h('div', { class: 'stack', hidden: true });
  let friendsLoaded = false;
  async function loadFriends() {
    friendsLoaded = true;
    friendsBox.append(skeletonCards(1));
    try {
      const r = await api.get(`/api/users/${encodeURIComponent(username)}/friends`);
      friendsBox.textContent = '';
      if (!r.users.length) friendsBox.append(emptyState('Aucun ami pour le moment'));
      for (const u of r.users) {
        friendsBox.append(h('div', { class: 'card' },
          h('a', { class: 'person-link', href: `#/u/${u.username}` },
            avatar(u, 'md'),
            h('div', { class: 'person-text' }, h('b', { text: u.display_name }), h('small', { text: u.bio || `@${u.username}` })))));
      }
    } catch (e) {
      friendsBox.textContent = '';
      friendsBox.append(errorState(e.message, () => { friendsBox.textContent = ''; loadFriends(); }));
    }
  }

  const tabs = [['posts', 'Publications'], ['friends', 'Amis']].map(([key, label]) =>
    h('button', {
      class: `seg${key === 'posts' ? ' on' : ''}`, type: 'button', role: 'tab', text: label, 'aria-selected': String(key === 'posts'),
      onclick: () => {
        for (const t of tabs) {
          const on = t === tabs[key === 'posts' ? 0 : 1];
          t.classList.toggle('on', on);
          t.setAttribute('aria-selected', String(on));
        }
        posts.el.hidden = key !== 'posts';
        friendsBox.hidden = key !== 'friends';
        if (key === 'friends' && !friendsLoaded) loadFriends();
      },
    }));

  root.textContent = '';
  root.append(header, h('div', { class: 'segmented', role: 'tablist', 'aria-label': 'Sections du profil' }, ...tabs), posts.el, friendsBox);
  posts.reload();
}
