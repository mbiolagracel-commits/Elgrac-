// Réglages : profil, photo, mot de passe, déconnexion.
import { api, uploadImage } from '../api.js';
import { state, setMe } from '../state.js';
import { h, icon, avatar, toast } from '../ui.js';

export default function settings({ root, logout }) {
  const me = state.me;

  /* ----- profil ----- */
  const avatarSlot = h('div', { class: 'avatar-slot' }, avatar(me, 'xl'));
  const fileInput = h('input', { type: 'file', accept: 'image/jpeg,image/png,image/webp', hidden: true });
  fileInput.addEventListener('change', async () => {
    const f = fileInput.files && fileInput.files[0];
    if (!f) return;
    try {
      const file = await uploadImage(f, 512);
      const r = await api.patch('/api/me', { avatar: file });
      setMe(r.user);
      avatarSlot.textContent = '';
      avatarSlot.append(avatar(r.user, 'xl'));
      toast('Photo de profil mise à jour');
    } catch (e) {
      toast(e.message, 'error');
    }
    fileInput.value = '';
  });

  const name = h('input', { id: 'display_name', type: 'text', minlength: '2', maxlength: '40', required: true, value: me.display_name, autocomplete: 'name' });
  const bio = h('textarea', { id: 'bio', rows: '3', maxlength: '160', placeholder: 'Une phrase pour te présenter' });
  bio.value = me.bio || '';
  const bioCount = h('small', { class: 'muted', text: `${bio.value.length}/160` });
  bio.addEventListener('input', () => { bioCount.textContent = `${bio.value.length}/160`; });
  const save = h('button', { class: 'btn primary', type: 'submit', text: 'Enregistrer' });

  const profileForm = h('form', { class: 'card form' },
    h('h2', { text: 'Mon profil' }),
    h('div', { class: 'avatar-edit' }, avatarSlot,
      h('button', { class: 'btn sm', type: 'button', onclick: () => fileInput.click() }, icon('camera'), 'Changer la photo'), fileInput),
    h('div', { class: 'field' }, h('label', { for: 'display_name', text: 'Nom affiché' }), name),
    h('div', { class: 'field' }, h('label', { for: 'bio', text: 'Description' }), bio, bioCount),
    h('p', { class: 'muted small', text: `Nom d'utilisateur : @${me.username} · E-mail : ${me.email}` }),
    save);
  profileForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    save.disabled = true;
    try {
      const r = await api.patch('/api/me', { display_name: name.value, bio: bio.value });
      setMe(r.user);
      toast('Profil enregistré');
    } catch (err) {
      toast(err.message, 'error');
    }
    save.disabled = false;
  });

  /* ----- mot de passe ----- */
  const current = h('input', { id: 'current', type: 'password', required: true, autocomplete: 'current-password', maxlength: '128' });
  const next = h('input', { id: 'next', type: 'password', required: true, minlength: '8', autocomplete: 'new-password', maxlength: '128' });
  const pwSave = h('button', { class: 'btn', type: 'submit', text: 'Changer le mot de passe' });
  const pwForm = h('form', { class: 'card form' },
    h('h2', { text: 'Mot de passe' }),
    h('div', { class: 'field' }, h('label', { for: 'current', text: 'Mot de passe actuel' }), current),
    h('div', { class: 'field' }, h('label', { for: 'next', text: 'Nouveau mot de passe (8 caractères minimum)' }), next),
    pwSave);
  pwForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    pwSave.disabled = true;
    try {
      await api.post('/api/me/password', { current: current.value, next: next.value });
      current.value = '';
      next.value = '';
      toast('Mot de passe changé. Tes autres appareils sont déconnectés.');
    } catch (err) {
      toast(err.message, 'error');
    }
    pwSave.disabled = false;
  });

  root.append(
    h('h1', { class: 'page-title', text: 'Réglages' }),
    profileForm, pwForm,
    h('div', { class: 'card form' },
      h('h2', { text: 'Session' }),
      h('button', { class: 'btn danger', type: 'button', onclick: logout }, icon('logout'), 'Se déconnecter')));
}
