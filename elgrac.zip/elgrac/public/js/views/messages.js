// Messages privés : liste des conversations et fil de discussion.
import { api } from '../api.js';
import { refreshCounters } from '../state.js';
import { h, icon, avatar, ago, clock, dayLabel, toast, errorState, emptyState, skeletonCards } from '../ui.js';

export async function conversations({ root }) {
  root.append(h('h1', { class: 'page-title', text: 'Messages' }), skeletonCards(2));
  try {
    const [convs, friends] = await Promise.all([api.get('/api/messages'), api.get('/api/friends')]);
    root.textContent = '';
    root.append(h('h1', { class: 'page-title', text: 'Messages' }));

    const list = h('div', { class: 'card list' });
    if (!convs.conversations.length) {
      list.append(emptyState('Aucune conversation', 'Écris à un ami pour commencer.'));
    }
    for (const c of convs.conversations) {
      list.append(h('a', { class: `conv${c.unread ? ' unread' : ''}`, href: `#/messages/${c.user.username}` },
        avatar(c.user, 'md'),
        h('div', { class: 'person-text' },
          h('b', { text: c.user.display_name }),
          h('small', { text: `${c.last_mine ? 'Toi : ' : ''}${c.last_body}` })),
        h('div', { class: 'conv-side' },
          h('small', { class: 'muted', text: ago(c.last_at) }),
          c.unread ? h('span', { class: 'badge static', text: String(c.unread) }) : null)));
    }
    root.append(list);

    if (friends.users.length) {
      const box = h('div', { class: 'friend-chips' });
      for (const u of friends.users) {
        box.append(h('a', { class: 'chip-link', href: `#/messages/${u.username}` }, avatar(u, 'sm'), u.display_name));
      }
      root.append(h('section', { class: 'stack' }, h('h2', { class: 'section-title', text: 'Écrire à un ami' }), box));
    }
  } catch (e) {
    root.textContent = '';
    root.append(h('h1', { class: 'page-title', text: 'Messages' }), errorState(e.message));
  }
}

export async function thread({ root, params }) {
  const username = params[0];
  const seen = new Set();
  let lastId = 0;
  let lastDay = '';
  let timer = null;
  let stopped = false;

  const body = h('div', { class: 'chat-body', 'aria-live': 'polite' });
  const input = h('input', { type: 'text', maxlength: '1000', placeholder: 'Écris un message', 'aria-label': 'Ton message', autocomplete: 'off' });
  const send = h('button', { class: 'btn primary icon-only', type: 'submit', 'aria-label': 'Envoyer' }, icon('send'));
  const form = h('form', { class: 'chat-form' }, input, send);
  const note = h('p', { class: 'chat-note', hidden: true });

  root.append(skeletonCards(1));
  let first;
  try {
    first = await api.get(`/api/messages/${encodeURIComponent(username)}`);
  } catch (e) {
    root.textContent = '';
    root.append(h('a', { class: 'back', href: '#/messages' }, icon('back'), 'Messages'),
      errorState(e.status === 404 ? "Ce membre n'existe pas." : e.message));
    return;
  }
  if (stopped) return;
  const other = first.user;
  document.title = `${other.display_name} · elgrac`;

  function add(messages) {
    const nearBottom = body.scrollHeight - body.scrollTop - body.clientHeight < 120;
    let mineAdded = false;
    for (const m of messages) {
      if (seen.has(m.id)) continue;
      seen.add(m.id);
      lastId = Math.max(lastId, m.id);
      const label = dayLabel(m.created_at);
      if (label !== lastDay) {
        lastDay = label;
        body.append(h('div', { class: 'day', text: label }));
      }
      const mine = m.sender_id !== other.id;
      if (mine) mineAdded = true;
      body.append(h('div', { class: `bubble ${mine ? 'mine' : 'theirs'}` }, h('span', { text: m.body }), h('small', { text: clock(m.created_at) })));
    }
    if (messages.length && (nearBottom || mineAdded)) body.scrollTop = body.scrollHeight;
  }

  function setCanSend(can) {
    input.disabled = !can;
    send.disabled = !can;
    note.hidden = can;
    if (!can) note.textContent = `Vous n'êtes pas amis : tu ne peux pas écrire à ${other.display_name}.`;
  }

  root.textContent = '';
  root.append(h('section', { class: 'chat card' },
    h('header', { class: 'chat-head' },
      h('a', { class: 'icon-btn', href: '#/messages', 'aria-label': 'Retour aux messages' }, icon('back')),
      h('a', { class: 'person-link', href: `#/u/${other.username}` },
        avatar(other, 'md'), h('div', { class: 'person-text' }, h('b', { text: other.display_name }), h('small', { text: `@${other.username}` })))),
    body, note, form));
  if (!first.messages.length) body.append(h('p', { class: 'chat-empty muted', text: `Dis bonjour à ${other.display_name}.` }));
  add(first.messages);
  body.scrollTop = body.scrollHeight;
  setCanSend(first.can_send);
  refreshCounters();

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const text = input.value.trim();
    if (!text) return;
    send.disabled = true;
    try {
      const r = await api.post(`/api/messages/${encodeURIComponent(username)}`, { body: text });
      input.value = '';
      const empty = body.querySelector('.chat-empty');
      if (empty) empty.remove();
      add([r.message]);
    } catch (err) {
      toast(err.message, 'error');
    }
    send.disabled = false;
    input.focus();
  });

  async function poll() {
    if (stopped || document.hidden) return;
    try {
      const r = await api.get(`/api/messages/${encodeURIComponent(username)}?after=${lastId}`);
      if (stopped) return;
      if (r.messages.length) {
        const empty = body.querySelector('.chat-empty');
        if (empty) empty.remove();
        add(r.messages);
        refreshCounters();
      }
      setCanSend(r.can_send);
    } catch { /* hors ligne : on réessaiera au prochain tour */ }
  }
  timer = setInterval(poll, 3500);

  return () => {
    stopped = true;
    clearInterval(timer);
  };
}
