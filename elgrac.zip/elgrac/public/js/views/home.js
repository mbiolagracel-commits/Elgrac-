// Page d'accueil : écrire une publication et lire le fil.
import { api } from '../api.js';
import { h, emptyState } from '../ui.js';
import { composer, feed } from '../components.js';

function savedScope() {
  try { return localStorage.getItem('elgrac.scope') === 'friends' ? 'friends' : 'all'; } catch { return 'all'; }
}

export default function home({ root }) {
  let scope = savedScope();

  const list = feed(
    (before) => api.get(`/api/posts?scope=${scope}${before ? `&before=${before}` : ''}`),
    () => (scope === 'friends'
      ? emptyState('Rien de tes amis pour le moment', 'Ajoute des amis pour voir leurs publications ici.',
          h('a', { class: 'btn sm primary', href: '#/friends', text: 'Trouver des amis' }))
      : emptyState('Le fil attend sa première publication', 'Écris la première, elle apparaîtra ici.')),
  );

  const tabs = [['all', 'Découvrir'], ['friends', 'Amis']].map(([key, label]) =>
    h('button', {
      class: 'seg', type: 'button', role: 'tab', text: label, 'data-scope': key,
      onclick: () => {
        if (scope === key) return;
        scope = key;
        try { localStorage.setItem('elgrac.scope', scope); } catch { /* stockage indisponible */ }
        paintTabs();
        list.reload();
      },
    }));
  function paintTabs() {
    for (const t of tabs) {
      const on = t.dataset.scope === scope;
      t.classList.toggle('on', on);
      t.setAttribute('aria-selected', String(on));
    }
  }
  paintTabs();

  root.append(
    composer({ onPost: (post) => list.prepend(post) }),
    h('div', { class: 'segmented', role: 'tablist', 'aria-label': 'Fil' }, ...tabs),
    list.el);
  list.reload();
}
