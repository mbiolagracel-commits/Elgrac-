// Notifications : j'aime, commentaires, demandes d'amis.
import { api } from '../api.js';
import { refreshCounters } from '../state.js';
import { h, avatar, ago, errorState, emptyState, skeletonCards } from '../ui.js';

const TEXT = {
  like: 'a aimé ta publication.',
  comment: 'a commenté ta publication.',
  friend_request: "t'a envoyé une demande d'ami.",
  friend_accept: 'a accepté ta demande d\'ami.',
};

function target(n) {
  if ((n.type === 'like' || n.type === 'comment') && n.post_id) return `#/post/${n.post_id}`;
  if (n.type === 'friend_request') return '#/friends';
  return `#/u/${n.actor.username}`;
}

export default async function notifications({ root }) {
  root.append(h('h1', { class: 'page-title', text: 'Notifications' }), skeletonCards(2));
  try {
    const r = await api.get('/api/notifications');
    root.textContent = '';
    root.append(h('h1', { class: 'page-title', text: 'Notifications' }));
    if (!r.notifications.length) {
      root.append(emptyState('Rien de nouveau', "Tu verras ici quand quelqu'un aime ou commente tes publications.", null));
      return;
    }
    const list = h('div', { class: 'card list' });
    for (const n of r.notifications) {
      list.append(h('a', { class: `notif${n.unread ? ' unread' : ''}`, href: target(n) },
        avatar(n.actor, 'md'),
        h('div', { class: 'person-text' },
          h('span', {}, h('b', { text: n.actor.display_name }), ` ${TEXT[n.type] || 'a interagi avec toi.'}`),
          h('small', { class: 'muted', text: ago(n.created_at) })),
        n.unread ? h('span', { class: 'dot', 'aria-label': 'Non lu' }) : null));
    }
    root.append(list);
    await api.post('/api/notifications/read');
    refreshCounters();
  } catch (e) {
    root.textContent = '';
    root.append(h('h1', { class: 'page-title', text: 'Notifications' }), errorState(e.message));
  }
}
