// Une seule publication, avec ses commentaires ouverts.
import { api } from '../api.js';
import { h, icon, errorState, skeletonCards } from '../ui.js';
import { postCard } from '../components.js';

export default async function postView({ root, params }) {
  root.append(h('a', { class: 'back', href: '#/' }, icon('back'), 'Retour au fil'), skeletonCards(1));
  try {
    const r = await api.get(`/api/posts/${params[0]}`);
    root.textContent = '';
    root.append(
      h('a', { class: 'back', href: '#/' }, icon('back'), 'Retour au fil'),
      postCard(r.post, { openComments: true, onDelete: () => { location.hash = '#/'; } }));
  } catch (e) {
    root.textContent = '';
    root.append(h('a', { class: 'back', href: '#/' }, icon('back'), 'Retour au fil'),
      errorState(e.status === 404 ? "Cette publication n'existe plus." : e.message));
  }
}
