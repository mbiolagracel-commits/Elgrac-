// Colonne de droite sur grand écran : demandes d'amis et suggestions.
import { api } from '../api.js';
import { h, avatar } from '../ui.js';
import { relationActions } from '../components.js';

let lastLoad = 0;

export async function renderAside(box, force = false) {
  if (!force && Date.now() - lastLoad < 20000 && box.childElementCount) return;
  lastLoad = Date.now();
  try {
    const [reqs, sugg] = await Promise.all([api.get('/api/friends/requests'), api.get('/api/users/suggestions')]);
    box.textContent = '';
    if (reqs.incoming.length) {
      const card = h('section', { class: 'card aside-card' }, h('h2', { class: 'section-title', text: "Demandes d'amis" }));
      for (const u of reqs.incoming.slice(0, 3)) {
        card.append(h('div', { class: 'aside-person' },
          h('a', { class: 'person-link', href: `#/u/${u.username}` }, avatar(u, 'sm'), h('b', { text: u.display_name })),
          relationActions(u, 'received')));
      }
      box.append(card);
    }
    if (sugg.users.length) {
      const card = h('section', { class: 'card aside-card' }, h('h2', { class: 'section-title', text: 'Personnes à découvrir' }));
      for (const u of sugg.users.slice(0, 4)) {
        card.append(h('div', { class: 'aside-person' },
          h('a', { class: 'person-link', href: `#/u/${u.username}` }, avatar(u, 'sm'), h('b', { text: u.display_name })),
          relationActions(u, 'none')));
      }
      box.append(card);
    }
  } catch { /* la colonne est facultative */ }
}
