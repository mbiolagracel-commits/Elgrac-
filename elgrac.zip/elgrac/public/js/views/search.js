// Recherche de personnes.
import { api } from '../api.js';
import { h, icon, debounce, errorState, emptyState } from '../ui.js';
import { personRow } from '../components.js';

export default function search({ root, query }) {
  const input = h('input', {
    type: 'search', placeholder: 'Nom ou nom d\'utilisateur', 'aria-label': 'Rechercher une personne',
    autocomplete: 'off', autocapitalize: 'none', maxlength: '40', value: query.get('q') || '',
  });
  const results = h('div', { class: 'stack', 'aria-live': 'polite' });
  let gen = 0;

  async function run() {
    const q = input.value.trim();
    const mine = ++gen;
    results.textContent = '';
    if (q.length < 2) {
      results.append(emptyState('Cherche une personne', 'Tape au moins 2 lettres de son nom ou de son nom d\'utilisateur.'));
      return;
    }
    try {
      const r = await api.get(`/api/users/search?q=${encodeURIComponent(q)}`);
      if (mine !== gen) return;
      results.textContent = '';
      if (!r.users.length) {
        results.append(emptyState('Aucun résultat', `Personne ne correspond à « ${q} ».`));
        return;
      }
      for (const u of r.users) results.append(h('div', { class: 'card' }, personRow(u, u.relation)));
    } catch (e) {
      if (mine !== gen) return;
      results.textContent = '';
      results.append(errorState(e.message, run));
    }
  }

  const form = h('form', { class: 'searchbar', role: 'search' }, icon('search'), input);
  form.addEventListener('submit', (e) => { e.preventDefault(); run(); });
  input.addEventListener('input', debounce(run, 300));

  root.append(h('h1', { class: 'page-title', text: 'Rechercher' }), form, results);
  run();
  input.focus();
}
