// Amis : demandes reçues, demandes envoyées, liste d'amis et suggestions.
import { api } from '../api.js';
import { h, errorState, skeletonCards, emptyState } from '../ui.js';
import { personRow } from '../components.js';

function section(title, count) {
  return h('section', { class: 'stack' },
    h('h2', { class: 'section-title' }, title, count != null ? h('span', { class: 'pill', text: String(count) }) : null));
}

export default async function friends({ root }) {
  root.append(h('h1', { class: 'page-title', text: 'Amis' }), skeletonCards(2));
  try {
    const [reqs, mine, sugg] = await Promise.all([
      api.get('/api/friends/requests'),
      api.get('/api/friends'),
      api.get('/api/users/suggestions'),
    ]);
    root.textContent = '';
    root.append(h('h1', { class: 'page-title', text: 'Amis' }));

    if (reqs.incoming.length) {
      const s = section('Demandes reçues', reqs.incoming.length);
      reqs.incoming.forEach((u) => s.append(h('div', { class: 'card' }, personRow(u, 'received'))));
      root.append(s);
    }
    if (reqs.sent.length) {
      const s = section('Demandes envoyées', reqs.sent.length);
      reqs.sent.forEach((u) => s.append(h('div', { class: 'card' }, personRow(u, 'sent'))));
      root.append(s);
    }

    const mineSection = section('Mes amis', mine.users.length);
    if (mine.users.length) {
      mine.users.forEach((u) => mineSection.append(h('div', { class: 'card' }, personRow(u, 'friends'))));
    } else {
      mineSection.append(emptyState("Tu n'as pas encore d'amis", 'Cherche des personnes que tu connais ou regarde les suggestions.',
        h('a', { class: 'btn sm primary', href: '#/search', text: 'Rechercher' })));
    }
    root.append(mineSection);

    if (sugg.users.length) {
      const s = section('Personnes à découvrir');
      sugg.users.forEach((u) => s.append(h('div', { class: 'card' }, personRow(u, 'none'))));
      root.append(s);
    }
  } catch (e) {
    root.textContent = '';
    root.append(h('h1', { class: 'page-title', text: 'Amis' }), errorState(e.message));
  }
}
