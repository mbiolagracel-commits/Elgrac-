// Connexion et création de compte.
import { api } from '../api.js';
import { h, star } from '../ui.js';

function field(id, label, props = {}) {
  return h('div', { class: 'field' },
    h('label', { for: id, text: label }),
    h('input', { id, name: id, required: true, ...props }));
}

export function mountAuth(root, mode, onAuth) {
  const register = mode === '/register';
  const error = h('p', { class: 'form-error', role: 'alert', hidden: true });
  const submit = h('button', { class: 'btn primary block', type: 'submit', text: register ? 'Créer mon compte' : 'Me connecter' });

  const password = field('password', 'Mot de passe', {
    type: 'password', minlength: register ? '8' : null, maxlength: '128',
    autocomplete: register ? 'new-password' : 'current-password',
  });
  const toggle = h('button', { class: 'link-btn', type: 'button', text: 'Afficher', 'aria-pressed': 'false' });
  toggle.addEventListener('click', () => {
    const input = password.querySelector('input');
    const show = input.type === 'password';
    input.type = show ? 'text' : 'password';
    toggle.textContent = show ? 'Masquer' : 'Afficher';
    toggle.setAttribute('aria-pressed', String(show));
  });
  password.append(toggle);

  const fields = register
    ? [
        field('display_name', 'Ton nom', { type: 'text', minlength: '2', maxlength: '40', autocomplete: 'name', placeholder: 'Ex. Grace Mbiola' }),
        field('username', "Nom d'utilisateur", { type: 'text', minlength: '3', maxlength: '20', pattern: '[A-Za-z0-9_.]{3,20}', autocomplete: 'username', placeholder: 'Ex. elgrac237', autocapitalize: 'none', spellcheck: 'false' }),
        field('email', 'Adresse e-mail', { type: 'email', maxlength: '120', autocomplete: 'email', inputmode: 'email' }),
        password,
      ]
    : [
        field('identifier', 'E-mail ou nom d\'utilisateur', { type: 'text', maxlength: '120', autocomplete: 'username', autocapitalize: 'none', spellcheck: 'false' }),
        password,
      ];

  const form = h('form', { class: 'auth-form', novalidate: true }, ...fields, error, submit);
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    error.hidden = true;
    if (!form.checkValidity()) {
      form.reportValidity();
      return;
    }
    const data = Object.fromEntries(new FormData(form));
    submit.disabled = true;
    submit.textContent = 'Un instant…';
    try {
      const r = await api.post(register ? '/api/auth/register' : '/api/auth/login', data, { noAuthRedirect: true });
      onAuth(r.user);
    } catch (err) {
      error.textContent = err.message;
      error.hidden = false;
      submit.disabled = false;
      submit.textContent = register ? 'Créer mon compte' : 'Me connecter';
    }
  });

  root.textContent = '';
  root.append(h('main', { class: 'auth' },
    h('section', { class: 'auth-hero' },
      h('div', { class: 'brand big' }, star(), 'elgrac'),
      h('h1', { text: 'Retrouve tes amis. Partage ce qui te passionne.' }),
      h('p', { text: 'Publie des photos et des idées, discute en privé avec tes amis et suis ce qui se passe autour de toi.' })),
    h('section', { class: 'auth-card card' },
      h('h2', { text: register ? 'Créer un compte' : 'Connexion' }),
      form,
      h('p', { class: 'auth-switch' },
        register ? 'Tu as déjà un compte ? ' : 'Nouveau sur elgrac ? ',
        h('a', { href: register ? '#/login' : '#/register', text: register ? 'Connecte-toi' : 'Crée ton compte' })))));
  const first = form.querySelector('input');
  if (first) first.focus();
}
