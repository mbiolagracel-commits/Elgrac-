// Petits outils pour construire la page : création d'éléments, icônes, avatars, messages, boîtes de dialogue.

export const $ = (sel, root = document) => root.querySelector(sel);

export function append(el, children) {
  for (const c of children.flat(Infinity)) {
    if (c == null || c === false) continue;
    el.append(c instanceof Node ? c : document.createTextNode(String(c)));
  }
}

/**
 * Crée un élément. Tout texte passe par textContent : le contenu des membres
 * n'est jamais interprété comme du HTML, ce qui bloque les attaques XSS.
 */
export function h(tag, props, ...children) {
  const el = document.createElement(tag);
  if (props) {
    for (const [k, v] of Object.entries(props)) {
      if (v == null || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k === 'text') el.textContent = v;
      else if (k === 'style') for (const [p, val] of Object.entries(v)) el.style.setProperty(p, val);
      else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
      else if (v === true) el.setAttribute(k, '');
      else el.setAttribute(k, v);
    }
  }
  append(el, children);
  return el;
}

/* ---------- icônes ---------- */
const PATHS = {
  home: '<path d="M3 11l9-8 9 8v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>',
  users: '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8"/>',
  chat: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
  bell: '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9M13.7 21a2 2 0 0 1-3.4 0"/>',
  user: '<path d="M20 21a8 8 0 0 0-16 0"/><circle cx="12" cy="7" r="4"/>',
  search: '<circle cx="11" cy="11" r="8"/><path d="M21 21l-4.3-4.3"/>',
  heart: '<path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>',
  image: '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/>',
  trash: '<path d="M3 6h18M8 6V4h8v2M6 6l1 14h10l1-14"/>',
  send: '<path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z"/>',
  close: '<path d="M18 6L6 18M6 6l12 12"/>',
  back: '<path d="M19 12H5M12 19l-7-7 7-7"/>',
  sliders: '<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',
  logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>',
  camera: '<path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/>',
};

export function icon(name) {
  const s = document.createElement('span');
  s.className = 'ico';
  s.setAttribute('aria-hidden', 'true');
  s.innerHTML = `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${PATHS[name] || ''}</svg>`;
  return s;
}

export function star() {
  const s = document.createElement('span');
  s.className = 'star';
  s.setAttribute('aria-hidden', 'true');
  s.innerHTML = '<svg viewBox="0 0 24 24"><polygon points="12,2 14.9,8.8 22,9.4 16.6,14.1 18.2,21.2 12,17.5 5.8,21.2 7.4,14.1 2,9.4 9.1,8.8"/></svg>';
  return s;
}

/* ---------- dates ---------- */
export function ago(ts) {
  const s = Math.max(0, (Date.now() - ts) / 1000);
  if (s < 45) return "à l'instant";
  const m = Math.round(s / 60);
  if (m < 60) return `il y a ${m} min`;
  const hr = Math.round(m / 60);
  if (hr < 24) return `il y a ${hr} h`;
  const d = Math.round(hr / 24);
  if (d < 7) return `il y a ${d} j`;
  return new Date(ts).toLocaleDateString('fr-FR', { day: 'numeric', month: 'short', year: new Date(ts).getFullYear() === new Date().getFullYear() ? undefined : 'numeric' });
}
export const fullDate = (ts) => new Date(ts).toLocaleString('fr-FR', { dateStyle: 'long', timeStyle: 'short' });
export const clock = (ts) => new Date(ts).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
export const memberSince = (ts) => new Date(ts).toLocaleDateString('fr-FR', { month: 'long', year: 'numeric' });
export function dayLabel(ts) {
  const d = new Date(ts);
  const today = new Date();
  const yesterday = new Date(Date.now() - 86400000);
  if (d.toDateString() === today.toDateString()) return "Aujourd'hui";
  if (d.toDateString() === yesterday.toDateString()) return 'Hier';
  return d.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' });
}
export const plural = (n, one, many) => `${n} ${n > 1 ? many : one}`;

/* ---------- avatars et images ---------- */
export const imgUrl = (file) => `/uploads/${file}`;

function hash(s) {
  let x = 0;
  for (let i = 0; i < s.length; i++) x = (x * 31 + s.charCodeAt(i)) | 0;
  return Math.abs(x);
}

/** size : 'sm' | 'md' | 'lg' | 'xl' */
export function avatar(user, size = 'md') {
  const cls = `avatar ${size}`;
  if (user && user.avatar) return h('img', { class: cls, src: imgUrl(user.avatar), alt: '', loading: 'lazy' });
  const name = (user && user.display_name) || '?';
  return h('span', {
    class: `${cls} initial`,
    'aria-hidden': 'true',
    style: { '--hue': String(hash((user && user.username) || name) % 360) },
    text: name.trim().charAt(0).toUpperCase() || '?',
  });
}

/* ---------- messages à l'écran ---------- */
let toastTimer;
export function toast(message, kind = 'info') {
  const t = $('#toast');
  t.textContent = message;
  t.className = `toast ${kind}`;
  t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { t.hidden = true; }, 3800);
}

export function skeletonCards(n = 2) {
  const frag = document.createDocumentFragment();
  for (let i = 0; i < n; i++) {
    frag.append(h('div', { class: 'card skel-card', 'aria-hidden': 'true' },
      h('div', { class: 'skel-row' }, h('span', { class: 'skel circle' }), h('span', { class: 'skel line w40' })),
      h('span', { class: 'skel line w90' }), h('span', { class: 'skel line w70' })));
  }
  return frag;
}

export function emptyState(title, text, action) {
  return h('div', { class: 'empty' }, h('b', { text: title }), text ? h('p', { text }) : null, action || null);
}

export function errorState(message, retry) {
  return h('div', { class: 'empty error', role: 'alert' }, h('b', { text: 'Oups' }), h('p', { text: message }),
    retry ? h('button', { class: 'btn sm', type: 'button', text: 'Réessayer', onclick: retry }) : null);
}

/* ---------- fenêtres ---------- */
export function confirmDialog(message, okLabel = 'Confirmer') {
  return new Promise((resolve) => {
    const previous = document.activeElement;
    const ok = h('button', { class: 'btn danger', type: 'button', text: okLabel });
    const cancel = h('button', { class: 'btn', type: 'button', text: 'Annuler' });
    const overlay = h('div', { class: 'overlay' },
      h('div', { class: 'dialog', role: 'alertdialog', 'aria-modal': 'true', 'aria-label': message },
        h('p', { text: message }), h('div', { class: 'dialog-actions' }, cancel, ok)));
    function close(value) {
      document.removeEventListener('keydown', onKey);
      overlay.remove();
      if (previous && previous.focus) previous.focus();
      resolve(value);
    }
    function onKey(e) { if (e.key === 'Escape') close(false); }
    ok.addEventListener('click', () => close(true));
    cancel.addEventListener('click', () => close(false));
    overlay.addEventListener('click', (e) => { if (e.target === overlay) close(false); });
    document.addEventListener('keydown', onKey);
    document.body.append(overlay);
    cancel.focus();
  });
}

export function lightbox(src, alt) {
  const close = h('button', { class: 'lightbox-close', type: 'button', 'aria-label': 'Fermer' }, icon('close'));
  const overlay = h('div', { class: 'lightbox', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Photo agrandie' },
    close, h('img', { src, alt: alt || '' }));
  function done() { document.removeEventListener('keydown', onKey); overlay.remove(); }
  function onKey(e) { if (e.key === 'Escape') done(); }
  overlay.addEventListener('click', done);
  document.addEventListener('keydown', onKey);
  document.body.append(overlay);
  close.focus();
}

export function autosize(textarea) {
  const fit = () => { textarea.style.height = 'auto'; textarea.style.height = `${Math.min(textarea.scrollHeight, 260)}px`; };
  textarea.addEventListener('input', fit);
  return fit;
}

export function debounce(fn, ms) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
}
