// État partagé : le membre connecté et les pastilles (demandes, messages, notifications).
import { api } from './api.js';

export const state = {
  me: null,
  counters: { notifications: 0, messages: 0, requests: 0 },
};

const listeners = new Set();
export function onChange(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}
function emit(kind) {
  for (const fn of listeners) fn(kind);
}

export function setMe(user) {
  state.me = user;
  if (!user) state.counters = { notifications: 0, messages: 0, requests: 0 };
  emit('me');
}

export async function refreshCounters() {
  if (!state.me) return;
  try {
    state.counters = await api.get('/api/counters', { noAuthRedirect: true });
    emit('counters');
  } catch { /* hors ligne : on réessaiera */ }
}
