// Point d'entrée : barre du haut, navigation, changement de page.
import { api } from './api.js';
import { state, onChange, setMe, refreshCounters } from './state.js';
import { h, icon, avatar, star, $, emptyState, errorState, toast } from './ui.js';
import { mountAuth } from './views/auth.js';
import home from './views/home.js';
import postView from './views/post.js';
import profile from './views/profile.js';
import friends from './views/friends.js';
import { conversations, thread } from './views/messages.js';
import notifications from './views/notifications.js';
import search from './views/search.js';
import settings from './views/settings.js';
import { renderAside } from './views/aside.js';

const ROUTES = [
  [/^\/$/, home, 'home', ''],
  [/^\/post\/(\d+)$/, postView, null, 'Publication'],
  [/^\/u\/([A-Za-z0-9_.]{1,20})$/, profile, 'profile', 'Profil'],
  [/^\/friends$/, friends, 'friends', 'Amis'],
  [/^\/messages$/, conversations, 'messages', 'Messages'],
  [/^\/messages\/([A-Za-z0-9_.]{1,20})$/, thread, 'messages', 'Messages'],
  [/^\/notifications$/, notifications, 'notifications', 'Notifications'],
  [/^\/search$/, search, null, 'Rechercher'],
  [/^\/settings$/, settings, null, 'Réglages'],
];

let shell = null;
let cleanup = null;
let token = 0;

/* ---------- barre du haut, menu latéral, barre du bas ---------- */
function buildShell() {
  const me = state.me;
  const items = [
    ['home', 'Accueil', 'home', '#/'],
    ['friends', 'Amis', 'users', '#/friends'],
    ['messages', 'Messages', 'chat', '#/messages'],
    ['notifications', 'Notifications', 'bell', '#/notifications'],
    ['me', 'Profil', 'user', `#/u/${me.username}`],
  ];
  const badgeOf = { friends: 'requests', messages: 'messages', notifications: 'notifications' };
  const links = [];

  function navLink(item, cls) {
    const [key, label, ic, href] = item;
    const badge = h('span', { class: 'badge', hidden: true });
    const a = h('a', { class: cls, href, 'data-key': key }, icon(ic), h('span', { class: 'label', text: label }), badge);
    links.push({ key, a, badge });
    return a;
  }

  const searchInput = h('input', { type: 'search', placeholder: 'Rechercher des personnes', 'aria-label': 'Rechercher des personnes', maxlength: '40', autocomplete: 'off' });
  const searchForm = h('form', { class: 'topsearch', role: 'search' }, icon('search'), searchInput);
  searchForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const q = searchInput.value.trim();
    location.hash = `#/search${q ? `?q=${encodeURIComponent(q)}` : ''}`;
  });

  const meBtn = h('button', { class: 'me-btn', type: 'button', 'aria-haspopup': 'menu', 'aria-expanded': 'false', 'aria-label': 'Mon compte' });
  const menu = h('div', { class: 'menu', role: 'menu', hidden: true },
    h('a', { role: 'menuitem', href: `#/u/${me.username}` }, icon('user'), 'Mon profil'),
    h('a', { role: 'menuitem', href: '#/settings' }, icon('sliders'), 'Réglages'),
    h('button', { role: 'menuitem', type: 'button', onclick: logout }, icon('logout'), 'Se déconnecter'));
  function closeMenu() {
    menu.hidden = true;
    meBtn.setAttribute('aria-expanded', 'false');
  }
  meBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    menu.hidden = !menu.hidden;
    meBtn.setAttribute('aria-expanded', String(!menu.hidden));
  });
  document.addEventListener('click', closeMenu);
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeMenu(); });
  menu.addEventListener('click', closeMenu);

  function paintMe() {
    meBtn.textContent = '';
    meBtn.append(avatar(state.me, 'sm'));
  }
  paintMe();

  const view = h('main', { id: 'view', tabindex: '-1' });
  const aside = h('aside', { class: 'aside', 'aria-label': 'Suggestions' });

  const el = h('div', { class: 'shell' },
    h('header', { class: 'topbar' }, h('div', { class: 'topbar-in' },
      h('a', { class: 'brand', href: '#/', 'aria-label': 'elgrac, accueil' }, star(), 'elgrac'),
      searchForm,
      h('a', { class: 'icon-btn mobile-search', href: '#/search', 'aria-label': 'Rechercher' }, icon('search')),
      h('div', { class: 'me-wrap' }, meBtn, menu))),
    h('div', { class: 'layout' },
      h('nav', { class: 'sidenav', 'aria-label': 'Navigation' }, ...items.map((i) => navLink(i, 'navlink'))),
      view,
      aside),
    h('nav', { class: 'bottomnav', 'aria-label': 'Navigation principale' }, ...items.map((i) => navLink(i, 'bottomlink'))));

  function paintBadges() {
    for (const l of links) {
      const n = badgeOf[l.key] ? state.counters[badgeOf[l.key]] : 0;
      l.badge.hidden = !n;
      l.badge.textContent = n > 99 ? '99+' : String(n);
      l.a.setAttribute('aria-label', n ? `${l.a.querySelector('.label').textContent}, ${n} nouveau${n > 1 ? 'x' : ''}` : l.a.querySelector('.label').textContent);
    }
  }
  const off = onChange((kind) => {
    if (kind === 'counters') paintBadges();
    if (kind === 'me' && state.me) paintMe();
  });

  return {
    el, view, aside, off,
    setActive(key) {
      for (const l of links) {
        if (l.key === key) l.a.setAttribute('aria-current', 'page');
        else l.a.removeAttribute('aria-current');
      }
    },
  };
}

/* ---------- connexion / déconnexion ---------- */
function onAuth(user) {
  setMe(user);
  history.replaceState(null, '', '#/');
  route();
}

async function logout() {
  try { await api.post('/api/auth/logout', undefined, { noAuthRedirect: true }); } catch { /* hors ligne */ }
  dropShell();
  setMe(null);
  history.replaceState(null, '', '#/login');
  route();
}

function dropShell() {
  if (cleanup) { try { cleanup(); } catch { /* ignoré */ } cleanup = null; }
  if (shell) { shell.off(); shell = null; }
}

/* ---------- changement de page ---------- */
async function route() {
  const mine = ++token;
  if (cleanup) { try { cleanup(); } catch { /* ignoré */ } cleanup = null; }

  const raw = location.hash.slice(1) || '/';
  const q = raw.indexOf('?');
  const path = q < 0 ? raw : raw.slice(0, q);
  const query = new URLSearchParams(q < 0 ? '' : raw.slice(q + 1));
  const app = $('#app');

  if (!state.me) {
    dropShell();
    const mode = path === '/register' ? '/register' : '/login';
    if (path !== mode) history.replaceState(null, '', `#${mode}`);
    document.title = mode === '/register' ? 'Créer un compte · elgrac' : 'Connexion · elgrac';
    mountAuth(app, mode, onAuth);
    return;
  }
  if (path === '/login' || path === '/register') {
    history.replaceState(null, '', '#/');
    return route();
  }

  if (!shell) {
    shell = buildShell();
    app.textContent = '';
    app.append(shell.el);
    refreshCounters();
  }

  // Chaque page travaille dans son propre conteneur : une page lente ne peut pas écrire dans la suivante.
  const root = h('div', { class: 'view-root' });
  shell.view.replaceChildren(root);
  window.scrollTo(0, 0);

  const found = ROUTES.find((r) => r[0].test(path));
  if (!found) {
    shell.setActive(null);
    document.title = 'Page introuvable · elgrac';
    root.append(emptyState('Page introuvable', "Cette adresse n'existe pas.", h('a', { class: 'btn sm primary', href: '#/', text: "Retour à l'accueil" })));
    return;
  }
  const [re, fn, key, title] = found;
  const params = re.exec(path).slice(1);
  shell.setActive(key === 'profile' ? (params[0].toLowerCase() === state.me.username.toLowerCase() ? 'me' : null) : key);
  document.title = title ? `${title} · elgrac` : 'elgrac';
  if ((key === 'home' || key === 'friends') && matchMedia('(min-width: 1240px)').matches) renderAside(shell.aside, key === 'friends');

  let result;
  try {
    result = await fn({ root, params, query, logout });
  } catch (e) {
    console.error(e);
    root.textContent = '';
    root.append(errorState("Cette page n'a pas pu s'afficher.", () => route()));
    return;
  }
  if (mine !== token) {
    if (typeof result === 'function') result();
    return;
  }
  cleanup = typeof result === 'function' ? result : null;
}

/* ---------- démarrage ---------- */
async function boot() {
  try {
    const r = await api.get('/api/me', { noAuthRedirect: true });
    state.me = r.user;
  } catch {
    state.me = null;
  }

  window.addEventListener('hashchange', route);
  window.addEventListener('elgrac:unauth', () => {
    if (!state.me) return;
    dropShell();
    setMe(null);
    toast('Ta session a expiré. Reconnecte-toi.', 'error');
    route();
  });
  setInterval(() => { if (state.me && !document.hidden) refreshCounters(); }, 15000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden && state.me) refreshCounters(); });
  window.addEventListener('online', () => { if (state.me) refreshCounters(); });

  route();

  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost')) {
    navigator.serviceWorker.register('/sw.js').catch(() => { /* l'application marche aussi sans */ });
  }
}

boot();
