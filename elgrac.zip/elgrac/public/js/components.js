// Éléments réutilisés dans plusieurs pages : publication, zone d'écriture, boutons d'amitié, fil.
import { api, uploadImage } from './api.js';
import { state, refreshCounters } from './state.js';
import {
  h, icon, avatar, ago, fullDate, imgUrl, toast, confirmDialog, lightbox, autosize,
  skeletonCards, errorState, emptyState,
} from './ui.js';

/* ---------- boutons d'amitié ---------- */
export function relationActions(user, initial, { onChange } = {}) {
  let rel = initial;
  let busy = false;
  const box = h('div', { class: 'rel' });

  async function act(fn, success) {
    if (busy) return;
    busy = true;
    paint();
    try {
      const r = await fn();
      if (r) {
        rel = r.relation;
        if (success) toast(success);
        if (onChange) onChange(rel);
      }
    } catch (e) {
      toast(e.message, 'error');
    }
    busy = false;
    paint();
    refreshCounters();
  }
  const btn = (label, cls, fn, success) =>
    h('button', { class: `btn sm ${cls}`, type: 'button', disabled: busy, text: label, onclick: () => act(fn, success) });

  function paint() {
    box.textContent = '';
    if (rel === 'self') return;
    if (rel === 'none') {
      box.append(btn('Ajouter', 'primary', () => api.post(`/api/friends/request/${user.id}`), 'Demande envoyée'));
    } else if (rel === 'sent') {
      box.append(btn('Annuler la demande', '', () => api.del(`/api/friends/${user.id}`), 'Demande annulée'));
    } else if (rel === 'received') {
      box.append(
        btn('Accepter', 'primary', () => api.post(`/api/friends/accept/${user.id}`), `Tu es maintenant ami(e) avec ${user.display_name}`),
        btn('Refuser', '', () => api.del(`/api/friends/${user.id}`)));
    } else if (rel === 'friends') {
      box.append(
        h('a', { class: 'btn sm', href: `#/messages/${user.username}`, text: 'Message' }),
        btn('Retirer', 'ghost', async () => {
          const ok = await confirmDialog(`Retirer ${user.display_name} de tes amis ?`, 'Retirer');
          return ok ? api.del(`/api/friends/${user.id}`) : null;
        }));
    }
  }
  paint();
  return box;
}

export function personRow(user, rel, sub) {
  return h('div', { class: 'person' },
    h('a', { class: 'person-link', href: `#/u/${user.username}` },
      avatar(user, 'md'),
      h('div', { class: 'person-text' },
        h('b', { text: user.display_name }),
        h('small', { text: sub || user.bio || `@${user.username}` }))),
    relationActions(user, rel));
}

/* ---------- publication ---------- */
export function postCard(post, { onDelete, openComments = false } = {}) {
  const me = state.me;
  const mine = post.author.id === me.id;
  let liked = post.liked;
  let likes = post.likes;
  let commentCount = post.comments;
  let busy = false;

  const likeNum = h('span', { class: 'count' });
  const likeBtn = h('button', { class: 'act', type: 'button', onclick: toggleLike }, icon('heart'), h('span', { text: "J'aime" }), likeNum);
  const commentNum = h('span', { class: 'count' });
  const commentBtn = h('button', { class: 'act', type: 'button', 'aria-expanded': 'false', onclick: () => toggleComments() },
    icon('chat'), h('span', { text: 'Commenter' }), commentNum);

  function paint() {
    likeBtn.classList.toggle('on', liked);
    likeBtn.setAttribute('aria-pressed', String(liked));
    likeNum.textContent = likes ? String(likes) : '';
    commentNum.textContent = commentCount ? String(commentCount) : '';
  }

  async function toggleLike() {
    if (busy) return;
    busy = true;
    const before = { liked, likes };
    liked = !liked;
    likes += liked ? 1 : -1;
    paint();
    try {
      const r = await api.post(`/api/posts/${post.id}/like`);
      liked = r.liked;
      likes = r.likes;
    } catch (e) {
      liked = before.liked;
      likes = before.likes;
      toast(e.message, 'error');
    }
    busy = false;
    paint();
  }

  /* commentaires, chargés au premier clic */
  const commentsBox = h('div', { class: 'comments', hidden: true });
  let loaded = false;
  const list = h('div', { class: 'comment-list' });
  const input = h('input', { type: 'text', maxlength: '500', placeholder: 'Écris un commentaire', 'aria-label': 'Ton commentaire', autocomplete: 'off' });
  const send = h('button', { class: 'icon-btn', type: 'submit', 'aria-label': 'Envoyer' }, icon('send'));
  const form = h('form', { class: 'comment-form' }, avatar(me, 'sm'), input, send);
  commentsBox.append(list, form);

  function commentRow(c) {
    const canDelete = c.author.id === me.id || mine;
    const row = h('div', { class: 'comment' },
      h('a', { href: `#/u/${c.author.username}`, 'aria-label': c.author.display_name }, avatar(c.author, 'sm')),
      h('div', { class: 'bubble-c' },
        h('a', { class: 'name', href: `#/u/${c.author.username}`, text: c.author.display_name }),
        h('p', { text: c.body }),
        h('small', { class: 'muted', text: ago(c.created_at) })),
      canDelete ? h('button', {
        class: 'icon-btn sm', type: 'button', 'aria-label': 'Supprimer ce commentaire',
        onclick: async () => {
          try {
            await api.del(`/api/comments/${c.id}`);
            row.remove();
            commentCount = Math.max(0, commentCount - 1);
            paint();
          } catch (e) { toast(e.message, 'error'); }
        },
      }, icon('trash')) : null);
    return row;
  }

  async function loadComments() {
    list.textContent = '';
    list.append(h('p', { class: 'muted small', text: 'Chargement…' }));
    try {
      const r = await api.get(`/api/posts/${post.id}/comments`);
      list.textContent = '';
      r.comments.forEach((c) => list.append(commentRow(c)));
      commentCount = r.comments.length;
      paint();
    } catch (e) {
      list.textContent = '';
      list.append(errorState(e.message, () => { loaded = false; loadComments(); }));
    }
  }

  async function toggleComments(force) {
    const show = force === undefined ? commentsBox.hidden : force;
    commentsBox.hidden = !show;
    commentBtn.setAttribute('aria-expanded', String(show));
    if (show && !loaded) {
      loaded = true;
      await loadComments();
    }
    if (show) input.focus({ preventScroll: true });
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const body = input.value.trim();
    if (!body) return;
    send.disabled = true;
    try {
      const r = await api.post(`/api/posts/${post.id}/comments`, { body });
      input.value = '';
      list.append(commentRow(r.comment));
      commentCount += 1;
      paint();
    } catch (err) {
      toast(err.message, 'error');
    }
    send.disabled = false;
  });

  const card = h('article', { class: 'card post' },
    h('header', { class: 'post-head' },
      h('a', { href: `#/u/${post.author.username}`, 'aria-label': post.author.display_name }, avatar(post.author, 'md')),
      h('div', { class: 'post-meta' },
        h('a', { class: 'name', href: `#/u/${post.author.username}`, text: post.author.display_name }),
        h('a', { class: 'time', href: `#/post/${post.id}`, title: fullDate(post.created_at), text: ago(post.created_at) })),
      mine ? h('button', {
        class: 'icon-btn', type: 'button', 'aria-label': 'Supprimer ma publication',
        onclick: async () => {
          if (!(await confirmDialog('Supprimer cette publication ?', 'Supprimer'))) return;
          try {
            await api.del(`/api/posts/${post.id}`);
            toast('Publication supprimée');
            if (onDelete) onDelete(card); else card.remove();
          } catch (e) { toast(e.message, 'error'); }
        },
      }, icon('trash')) : null),
    post.body ? h('p', { class: 'post-body', text: post.body }) : null,
    post.image ? h('button', {
      class: 'img-btn', type: 'button', 'aria-label': 'Agrandir la photo',
      onclick: () => lightbox(imgUrl(post.image), `Photo de ${post.author.display_name}`),
    }, h('img', { class: 'post-img', src: imgUrl(post.image), alt: `Photo publiée par ${post.author.display_name}`, loading: 'lazy' })) : null,
    h('div', { class: 'post-actions' }, likeBtn, commentBtn),
    commentsBox);

  paint();
  if (openComments) toggleComments(true);
  return card;
}

/* ---------- zone « Quoi de neuf ? » ---------- */
export function composer({ onPost }) {
  const me = state.me;
  const first = me.display_name.split(' ')[0];
  const text = h('textarea', { rows: '2', maxlength: '2000', placeholder: `Quoi de neuf, ${first} ?`, 'aria-label': 'Ta publication' });
  const fit = autosize(text);
  const fileInput = h('input', { type: 'file', accept: 'image/jpeg,image/png,image/webp,image/gif', hidden: true });
  const preview = h('div', { class: 'preview', hidden: true });
  const submit = h('button', { class: 'btn primary', type: 'submit', text: 'Publier' });
  const counter = h('span', { class: 'muted small', 'aria-hidden': 'true' });
  let file = null;
  let previewUrl = null;

  function clearImage() {
    file = null;
    fileInput.value = '';
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    previewUrl = null;
    preview.hidden = true;
    preview.textContent = '';
  }
  fileInput.addEventListener('change', () => {
    const f = fileInput.files && fileInput.files[0];
    if (!f) return;
    if (!f.type.startsWith('image/')) { toast('Choisis une image.', 'error'); fileInput.value = ''; return; }
    clearImage();
    file = f;
    previewUrl = URL.createObjectURL(f);
    preview.hidden = false;
    preview.append(
      h('img', { src: previewUrl, alt: 'Aperçu de la photo' }),
      h('button', { class: 'icon-btn', type: 'button', 'aria-label': 'Retirer la photo', onclick: clearImage }, icon('close')));
  });
  text.addEventListener('input', () => {
    counter.textContent = text.value.length > 1700 ? `${text.value.length}/2000` : '';
  });

  const form = h('form', { class: 'card composer' },
    h('div', { class: 'composer-row' }, avatar(me, 'md'), text),
    preview,
    h('div', { class: 'composer-actions' },
      h('button', { class: 'btn ghost sm', type: 'button', onclick: () => fileInput.click() }, icon('image'), 'Photo'),
      fileInput, counter, submit));

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const body = text.value.trim();
    if (!body && !file) { toast('Écris quelque chose ou ajoute une photo.', 'error'); return; }
    submit.disabled = true;
    submit.textContent = file ? 'Envoi de la photo…' : 'Publication…';
    try {
      const image = file ? await uploadImage(file) : null;
      const r = await api.post('/api/posts', { body, image });
      text.value = '';
      counter.textContent = '';
      fit();
      clearImage();
      onPost(r.post);
    } catch (err) {
      toast(err.message, 'error');
    }
    submit.disabled = false;
    submit.textContent = 'Publier';
  });
  return form;
}

/* ---------- liste de publications avec « Voir plus » ---------- */
export function feed(fetchPage, makeEmpty) {
  const list = h('div', { class: 'stack' });
  const more = h('button', { class: 'btn block', type: 'button', text: 'Voir plus de publications', hidden: true, onclick: () => load(false) });
  const el = h('div', { class: 'stack' }, list, more);
  let next = null;
  let gen = 0;
  let loading = false;
  let count = 0;

  function onDelete(card) {
    card.remove();
    count -= 1;
    if (count <= 0) list.append(makeEmpty());
  }
  function dropEmpty() {
    const e = list.querySelector('.empty');
    if (e) e.remove();
  }

  async function load(reset) {
    if (loading && !reset) return;
    if (reset) {
      gen += 1;
      next = null;
      count = 0;
      more.hidden = true;
      list.textContent = '';
      list.append(skeletonCards(2));
    }
    const mine = gen;
    loading = true;
    more.disabled = true;
    try {
      const r = await fetchPage(next);
      if (mine !== gen) return;
      if (reset) list.textContent = '';
      for (const p of r.posts) {
        list.append(postCard(p, { onDelete }));
        count += 1;
      }
      next = r.next;
      more.hidden = !next;
      if (!count) list.append(makeEmpty());
    } catch (e) {
      if (mine !== gen) return;
      if (reset) {
        list.textContent = '';
        list.append(errorState(e.message, () => load(true)));
      } else {
        toast(e.message, 'error');
      }
    } finally {
      if (mine === gen) {
        loading = false;
        more.disabled = false;
      }
    }
  }

  return {
    el,
    reload: () => load(true),
    prepend(post) {
      dropEmpty();
      list.prepend(postCard(post, { onDelete }));
      count += 1;
    },
  };
}

export { emptyState };
