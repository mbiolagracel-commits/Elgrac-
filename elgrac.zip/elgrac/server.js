'use strict';
const http = require('node:http');
const os = require('node:os');
const { db } = require('./src/db');
const {
  HttpError, Router, hit, clientIp, readJson, sendJson, sendError,
  checkOrigin, setSecurityHeaders, serveStatic,
} = require('./src/http');
const auth = require('./src/auth');

const BODY_METHODS = new Set(['POST', 'PATCH', 'PUT', 'DELETE']);
const QUIET = process.env.LOG_REQUESTS === '0';

function buildRouter() {
  const router = new Router();
  for (const name of ['auth', 'upload', 'users', 'posts', 'friends', 'messages', 'notifications']) {
    require(`./src/routes/${name}`)(router);
  }
  router.get('/api/health', () => ({ ok: true }));
  return router;
}

async function handleApi(router, req, res, url) {
  const ip = clientIp(req);
  hit(`api:${ip}`, 1200, 60_000);

  let matched;
  try {
    matched = router.match(req.method, url.pathname);
  } catch {
    throw new HttpError(400, 'Adresse invalide.');
  }
  if (!matched) throw new HttpError(404, 'Introuvable.');
  const { route, params } = matched;

  if (BODY_METHODS.has(req.method)) checkOrigin(req);

  const ctx = {
    req, res, url, params, ip,
    query: Object.fromEntries(url.searchParams),
    body: {},
    user: auth.loadUser(req),
  };
  if (route.opts.auth && !ctx.user) throw new HttpError(401, 'Connecte-toi pour continuer.');
  if (route.opts.rate) {
    const [name, max, windowMs, by] = route.opts.rate;
    hit(`${name}:${by === 'user' && ctx.user ? 'u' + ctx.user.id : ip}`, max, windowMs);
  }
  if (BODY_METHODS.has(req.method) && !route.opts.raw) ctx.body = await readJson(req);

  const result = await route.handler(ctx);
  if (!res.writableEnded) sendJson(res, 200, result === undefined ? { ok: true } : result);
}

function createServer() {
  const router = buildRouter();
  const server = http.createServer(async (req, res) => {
    const started = Date.now();
    setSecurityHeaders(res);
    let isApi = false;
    try {
      const url = new URL(req.url, 'http://localhost');
      isApi = url.pathname.startsWith('/api/');
      if (isApi) await handleApi(router, req, res, url);
      else await serveStatic(req, res, url);
    } catch (e) {
      sendError(res, e);
    }
    if (isApi && !QUIET) console.log(`${req.method} ${req.url.split('?')[0]} ${res.statusCode} ${Date.now() - started} ms`);
  });
  server.requestTimeout = 60_000;
  server.headersTimeout = 20_000;
  return server;
}

function lanAddresses() {
  const out = [];
  for (const list of Object.values(os.networkInterfaces())) {
    for (const a of list || []) if (a.family === 'IPv4' && !a.internal) out.push(a.address);
  }
  return out;
}

if (require.main === module) {
  const PORT = Number(process.env.PORT) || 3000;
  const HOST = process.env.HOST || '0.0.0.0';
  auth.purgeExpiredSessions();
  setInterval(auth.purgeExpiredSessions, 60 * 60 * 1000).unref();

  const server = createServer();
  server.listen(PORT, HOST, () => {
    console.log('\n  elgrac est lancé.\n');
    console.log(`  Sur cet ordinateur : http://localhost:${PORT}`);
    for (const ip of lanAddresses()) console.log(`  Sur ton téléphone (même Wi-Fi) : http://${ip}:${PORT}`);
    console.log('\n  Pour arrêter : Ctrl + C\n');
  });
  const stop = () => { server.close(() => { db.close(); process.exit(0); }); setTimeout(() => process.exit(0), 3000).unref(); };
  process.on('SIGINT', stop);
  process.on('SIGTERM', stop);
}

module.exports = { createServer };
